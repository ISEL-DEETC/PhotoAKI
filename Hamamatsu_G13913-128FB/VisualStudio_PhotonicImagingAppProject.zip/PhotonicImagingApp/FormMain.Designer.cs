﻿
using System.Drawing;
using System.Windows.Forms;

namespace PhotonicImagingApp
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveConfigurationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadConfigurationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.exportDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clearHistoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deviceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.selectCOMPortToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.comboSelCOM = new System.Windows.Forms.ToolStripComboBox();
            this.connectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.disconnectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.configurationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.singleAcquisitionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.startToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.graphOptionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showLinePlotToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showTimePlotToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.utilitiesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cOMConsoleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripProgressBar1 = new System.Windows.Forms.ToolStripProgressBar();
            this.toolStripStatusLabelPort = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStrip = new System.Windows.Forms.ToolStrip();
            this.toolStripButtonSingAcq = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonContAcq = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonExportData = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonDeleteHistory = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonImportData = new System.Windows.Forms.ToolStripButton();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.saveDataDialog = new System.Windows.Forms.SaveFileDialog();
            this.tabGraph = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.numShift = new System.Windows.Forms.NumericUpDown();
            this.labelShift = new System.Windows.Forms.Label();
            this.numStepdB = new System.Windows.Forms.NumericUpDown();
            this.labelStep = new System.Windows.Forms.Label();
            this.labelSelectData = new System.Windows.Forms.Label();
            this.comboSelectData = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboDatatype = new System.Windows.Forms.ComboBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.labelMin = new System.Windows.Forms.Label();
            this.labelMax = new System.Windows.Forms.Label();
            this.numMin = new System.Windows.Forms.NumericUpDown();
            this.numMax = new System.Windows.Forms.NumericUpDown();
            this.chkTimePlotDB = new System.Windows.Forms.CheckBox();
            this.numRefresh = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.numShowN = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.saveConfigDialog = new System.Windows.Forms.SaveFileDialog();
            this.openConfigDialog = new System.Windows.Forms.OpenFileDialog();
            this.loadDataDialog = new System.Windows.Forms.OpenFileDialog();
            this.menuStrip1.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.toolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabGraph.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numShift)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numStepdB)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numRefresh)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numShowN)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.deviceToolStripMenuItem,
            this.graphOptionsToolStripMenuItem,
            this.utilitiesToolStripMenuItem,
            this.aboutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(624, 24);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveConfigurationToolStripMenuItem,
            this.loadConfigurationToolStripMenuItem,
            this.toolStripSeparator2,
            this.exportDataToolStripMenuItem,
            this.importDataToolStripMenuItem,
            this.clearHistoryToolStripMenuItem,
            this.toolStripSeparator1,
            this.closeToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // saveConfigurationToolStripMenuItem
            // 
            this.saveConfigurationToolStripMenuItem.Name = "saveConfigurationToolStripMenuItem";
            this.saveConfigurationToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.saveConfigurationToolStripMenuItem.Text = "Save configuration";
            this.saveConfigurationToolStripMenuItem.Click += new System.EventHandler(this.saveConfigurationToolStripMenuItem_Click);
            // 
            // loadConfigurationToolStripMenuItem
            // 
            this.loadConfigurationToolStripMenuItem.Name = "loadConfigurationToolStripMenuItem";
            this.loadConfigurationToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.loadConfigurationToolStripMenuItem.Text = "Load configuration";
            this.loadConfigurationToolStripMenuItem.Click += new System.EventHandler(this.loadConfigurationToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(172, 6);
            // 
            // exportDataToolStripMenuItem
            // 
            this.exportDataToolStripMenuItem.Name = "exportDataToolStripMenuItem";
            this.exportDataToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.exportDataToolStripMenuItem.Text = "Export data";
            this.exportDataToolStripMenuItem.Click += new System.EventHandler(this.exportData);
            // 
            // importDataToolStripMenuItem
            // 
            this.importDataToolStripMenuItem.Name = "importDataToolStripMenuItem";
            this.importDataToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.importDataToolStripMenuItem.Text = "Import Data";
            this.importDataToolStripMenuItem.Click += new System.EventHandler(this.importData);
            // 
            // clearHistoryToolStripMenuItem
            // 
            this.clearHistoryToolStripMenuItem.Name = "clearHistoryToolStripMenuItem";
            this.clearHistoryToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.clearHistoryToolStripMenuItem.Text = "Clear data";
            this.clearHistoryToolStripMenuItem.Click += new System.EventHandler(this.clearData);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(172, 6);
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
            // 
            // deviceToolStripMenuItem
            // 
            this.deviceToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.selectCOMPortToolStripMenuItem,
            this.connectToolStripMenuItem,
            this.disconnectToolStripMenuItem,
            this.toolStripSeparator3,
            this.configurationToolStripMenuItem,
            this.toolStripSeparator4,
            this.singleAcquisitionToolStripMenuItem,
            this.startToolStripMenuItem});
            this.deviceToolStripMenuItem.Name = "deviceToolStripMenuItem";
            this.deviceToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.deviceToolStripMenuItem.Text = "Device";
            // 
            // selectCOMPortToolStripMenuItem
            // 
            this.selectCOMPortToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.comboSelCOM});
            this.selectCOMPortToolStripMenuItem.Name = "selectCOMPortToolStripMenuItem";
            this.selectCOMPortToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.selectCOMPortToolStripMenuItem.Text = "Select COM port";
            // 
            // comboSelCOM
            // 
            this.comboSelCOM.Name = "comboSelCOM";
            this.comboSelCOM.Size = new System.Drawing.Size(121, 23);
            this.comboSelCOM.Text = "Click to scan ports";
            this.comboSelCOM.Click += new System.EventHandler(this.selectCOMPortToolStripMenuItem_Click);
            // 
            // connectToolStripMenuItem
            // 
            this.connectToolStripMenuItem.Name = "connectToolStripMenuItem";
            this.connectToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.connectToolStripMenuItem.Text = "Connect";
            this.connectToolStripMenuItem.Click += new System.EventHandler(this.connectToolStripMenuItem_Click);
            // 
            // disconnectToolStripMenuItem
            // 
            this.disconnectToolStripMenuItem.Name = "disconnectToolStripMenuItem";
            this.disconnectToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.disconnectToolStripMenuItem.Text = "Disconnect";
            this.disconnectToolStripMenuItem.Click += new System.EventHandler(this.disconnectToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(221, 6);
            // 
            // configurationToolStripMenuItem
            // 
            this.configurationToolStripMenuItem.Name = "configurationToolStripMenuItem";
            this.configurationToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.configurationToolStripMenuItem.Text = "Configuration";
            this.configurationToolStripMenuItem.Click += new System.EventHandler(this.configurationToolStripMenuItem_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(221, 6);
            // 
            // singleAcquisitionToolStripMenuItem
            // 
            this.singleAcquisitionToolStripMenuItem.Name = "singleAcquisitionToolStripMenuItem";
            this.singleAcquisitionToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.singleAcquisitionToolStripMenuItem.Text = "Single acquisition";
            this.singleAcquisitionToolStripMenuItem.Click += new System.EventHandler(this.SingleAcquisition);
            // 
            // startToolStripMenuItem
            // 
            this.startToolStripMenuItem.Name = "startToolStripMenuItem";
            this.startToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.startToolStripMenuItem.Text = "Start/Stop continuous mode";
            this.startToolStripMenuItem.Click += new System.EventHandler(this.StartStopAcquire);
            // 
            // graphOptionsToolStripMenuItem
            // 
            this.graphOptionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.showLinePlotToolStripMenuItem,
            this.showTimePlotToolStripMenuItem});
            this.graphOptionsToolStripMenuItem.Name = "graphOptionsToolStripMenuItem";
            this.graphOptionsToolStripMenuItem.Size = new System.Drawing.Size(96, 20);
            this.graphOptionsToolStripMenuItem.Text = "Graph Options";
            // 
            // showLinePlotToolStripMenuItem
            // 
            this.showLinePlotToolStripMenuItem.Checked = true;
            this.showLinePlotToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.showLinePlotToolStripMenuItem.Name = "showLinePlotToolStripMenuItem";
            this.showLinePlotToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.showLinePlotToolStripMenuItem.Text = "Show line plot";
            this.showLinePlotToolStripMenuItem.Click += new System.EventHandler(this.showLinePlotToolStripMenuItem_Click);
            // 
            // showTimePlotToolStripMenuItem
            // 
            this.showTimePlotToolStripMenuItem.Name = "showTimePlotToolStripMenuItem";
            this.showTimePlotToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.showTimePlotToolStripMenuItem.Text = "Show time plot";
            this.showTimePlotToolStripMenuItem.Click += new System.EventHandler(this.showTimePlotToolStripMenuItem_Click);
            // 
            // utilitiesToolStripMenuItem
            // 
            this.utilitiesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cOMConsoleToolStripMenuItem});
            this.utilitiesToolStripMenuItem.Name = "utilitiesToolStripMenuItem";
            this.utilitiesToolStripMenuItem.Size = new System.Drawing.Size(58, 20);
            this.utilitiesToolStripMenuItem.Text = "Utilities";
            // 
            // cOMConsoleToolStripMenuItem
            // 
            this.cOMConsoleToolStripMenuItem.Name = "cOMConsoleToolStripMenuItem";
            this.cOMConsoleToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.cOMConsoleToolStripMenuItem.Text = "COM Console";
            this.cOMConsoleToolStripMenuItem.Click += new System.EventHandler(this.cOMConsoleToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel,
            this.toolStripProgressBar1,
            this.toolStripStatusLabelPort});
            this.statusStrip.Location = new System.Drawing.Point(0, 419);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(624, 22);
            this.statusStrip.TabIndex = 5;
            this.statusStrip.Text = "statusStrip1";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(441, 17);
            this.toolStripStatusLabel.Spring = true;
            this.toolStripStatusLabel.Text = "Select COM port and connect device to start.";
            // 
            // toolStripProgressBar1
            // 
            this.toolStripProgressBar1.Name = "toolStripProgressBar1";
            this.toolStripProgressBar1.Size = new System.Drawing.Size(100, 16);
            // 
            // toolStripStatusLabelPort
            // 
            this.toolStripStatusLabelPort.Name = "toolStripStatusLabelPort";
            this.toolStripStatusLabelPort.Size = new System.Drawing.Size(66, 17);
            this.toolStripStatusLabelPort.Text = "Port closed";
            // 
            // toolStrip
            // 
            this.toolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButtonSingAcq,
            this.toolStripButtonContAcq,
            this.toolStripButtonExportData,
            this.toolStripButtonDeleteHistory,
            this.toolStripButtonImportData});
            this.toolStrip.Location = new System.Drawing.Point(0, 24);
            this.toolStrip.Name = "toolStrip";
            this.toolStrip.Size = new System.Drawing.Size(624, 25);
            this.toolStrip.TabIndex = 6;
            this.toolStrip.Text = "toolStrip1";
            // 
            // toolStripButtonSingAcq
            // 
            this.toolStripButtonSingAcq.Image = global::PhotonicImagingApp.Properties.Resources.StartGraphicDiagnostics_16x;
            this.toolStripButtonSingAcq.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonSingAcq.Name = "toolStripButtonSingAcq";
            this.toolStripButtonSingAcq.Size = new System.Drawing.Size(68, 22);
            this.toolStripButtonSingAcq.Text = "Acquire";
            this.toolStripButtonSingAcq.ToolTipText = "Starts a single image acquisition.";
            this.toolStripButtonSingAcq.Click += new System.EventHandler(this.SingleAcquisition);
            // 
            // toolStripButtonContAcq
            // 
            this.toolStripButtonContAcq.Image = global::PhotonicImagingApp.Properties.Resources.StartWithoutDebug_16x;
            this.toolStripButtonContAcq.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonContAcq.Name = "toolStripButtonContAcq";
            this.toolStripButtonContAcq.Size = new System.Drawing.Size(80, 22);
            this.toolStripButtonContAcq.Text = "Start/Stop";
            this.toolStripButtonContAcq.ToolTipText = "Starts/Stops continuous image acquisition.";
            this.toolStripButtonContAcq.Click += new System.EventHandler(this.StartStopAcquire);
            // 
            // toolStripButtonExportData
            // 
            this.toolStripButtonExportData.Image = global::PhotonicImagingApp.Properties.Resources.ExportToExcel_16x;
            this.toolStripButtonExportData.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonExportData.Name = "toolStripButtonExportData";
            this.toolStripButtonExportData.Size = new System.Drawing.Size(87, 22);
            this.toolStripButtonExportData.Text = "Export data";
            this.toolStripButtonExportData.ToolTipText = "Export data to .csv file.";
            this.toolStripButtonExportData.Click += new System.EventHandler(this.exportData);
            // 
            // toolStripButtonDeleteHistory
            // 
            this.toolStripButtonDeleteHistory.Image = global::PhotonicImagingApp.Properties.Resources.DeleteAllRows_16x;
            this.toolStripButtonDeleteHistory.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonDeleteHistory.Name = "toolStripButtonDeleteHistory";
            this.toolStripButtonDeleteHistory.Size = new System.Drawing.Size(80, 22);
            this.toolStripButtonDeleteHistory.Text = "Clear data";
            this.toolStripButtonDeleteHistory.ToolTipText = "Clears all acquired data";
            this.toolStripButtonDeleteHistory.Click += new System.EventHandler(this.clearData);
            // 
            // toolStripButtonImportData
            // 
            this.toolStripButtonImportData.Image = global::PhotonicImagingApp.Properties.Resources.importIcon3;
            this.toolStripButtonImportData.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonImportData.Name = "toolStripButtonImportData";
            this.toolStripButtonImportData.Size = new System.Drawing.Size(89, 22);
            this.toolStripButtonImportData.Text = "Import data";
            this.toolStripButtonImportData.Click += new System.EventHandler(this.importData);
            // 
            // chart1
            // 
            this.chart1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            legend1.Enabled = false;
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(0, 0);
            this.chart1.Name = "chart1";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.Legend = "Legend1";
            series1.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series1.Name = "Series1";
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(620, 332);
            this.chart1.TabIndex = 8;
            this.chart1.Text = "chart1";
            this.chart1.GetToolTipText += new System.EventHandler<System.Windows.Forms.DataVisualization.Charting.ToolTipEventArgs>(this.Chart1_GetToolTipText);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.Padding = new System.Windows.Forms.Padding(80);
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.RowHeadersWidth = 10;
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dataGridView1.ShowEditingIcon = false;
            this.dataGridView1.Size = new System.Drawing.Size(616, 333);
            this.dataGridView1.TabIndex = 7;
            this.dataGridView1.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dataGridView1_RowPostPaint);
            this.dataGridView1.SelectionChanged += new System.EventHandler(this.myDataGridView_SelectionChanged);
            this.dataGridView1.Resize += new System.EventHandler(this.dataGridView1_Resize);
            // 
            // saveDataDialog
            // 
            this.saveDataDialog.FileOk += new System.ComponentModel.CancelEventHandler(this.saveDataDialog_FileOk);
            // 
            // tabGraph
            // 
            this.tabGraph.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tabGraph.Controls.Add(this.tabPage1);
            this.tabGraph.Controls.Add(this.tabPage2);
            this.tabGraph.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabGraph.ItemSize = new System.Drawing.Size(0, 1);
            this.tabGraph.Location = new System.Drawing.Point(0, 49);
            this.tabGraph.Name = "tabGraph";
            this.tabGraph.SelectedIndex = 0;
            this.tabGraph.Size = new System.Drawing.Size(624, 370);
            this.tabGraph.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabGraph.TabIndex = 9;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.numShift);
            this.tabPage1.Controls.Add(this.labelShift);
            this.tabPage1.Controls.Add(this.numStepdB);
            this.tabPage1.Controls.Add(this.labelStep);
            this.tabPage1.Controls.Add(this.labelSelectData);
            this.tabPage1.Controls.Add(this.comboSelectData);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.comboDatatype);
            this.tabPage1.Controls.Add(this.chart1);
            this.tabPage1.Location = new System.Drawing.Point(4, 5);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(616, 361);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Line plot";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // numShift
            // 
            this.numShift.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.numShift.Increment = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.numShift.Location = new System.Drawing.Point(567, 338);
            this.numShift.Maximum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.numShift.Minimum = new decimal(new int[] {
            50,
            0,
            0,
            -2147483648});
            this.numShift.Name = "numShift";
            this.numShift.Size = new System.Drawing.Size(46, 20);
            this.numShift.TabIndex = 20;
            this.numShift.ValueChanged += new System.EventHandler(this.numShift_ValueChanged);
            // 
            // labelShift
            // 
            this.labelShift.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.labelShift.AutoSize = true;
            this.labelShift.Location = new System.Drawing.Point(508, 340);
            this.labelShift.Name = "labelShift";
            this.labelShift.Size = new System.Drawing.Size(53, 13);
            this.labelShift.TabIndex = 19;
            this.labelShift.Text = "Shift (dB):";
            // 
            // numStepdB
            // 
            this.numStepdB.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.numStepdB.Location = new System.Drawing.Point(463, 338);
            this.numStepdB.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numStepdB.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numStepdB.Name = "numStepdB";
            this.numStepdB.Size = new System.Drawing.Size(39, 20);
            this.numStepdB.TabIndex = 18;
            this.numStepdB.Value = new decimal(new int[] {
            6,
            0,
            0,
            0});
            this.numStepdB.ValueChanged += new System.EventHandler(this.numStepdB_ValueChanged);
            // 
            // labelStep
            // 
            this.labelStep.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.labelStep.AutoSize = true;
            this.labelStep.Location = new System.Drawing.Point(403, 340);
            this.labelStep.Name = "labelStep";
            this.labelStep.Size = new System.Drawing.Size(54, 13);
            this.labelStep.TabIndex = 17;
            this.labelStep.Text = "Step (dB):";
            // 
            // labelSelectData
            // 
            this.labelSelectData.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.labelSelectData.AutoSize = true;
            this.labelSelectData.Location = new System.Drawing.Point(146, 340);
            this.labelSelectData.Name = "labelSelectData";
            this.labelSelectData.Size = new System.Drawing.Size(61, 13);
            this.labelSelectData.TabIndex = 13;
            this.labelSelectData.Text = "Show data:";
            // 
            // comboSelectData
            // 
            this.comboSelectData.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.comboSelectData.FormattingEnabled = true;
            this.comboSelectData.Items.AddRange(new object[] {
            "Last"});
            this.comboSelectData.Location = new System.Drawing.Point(228, 337);
            this.comboSelectData.Name = "comboSelectData";
            this.comboSelectData.Size = new System.Drawing.Size(84, 21);
            this.comboSelectData.TabIndex = 12;
            this.comboSelectData.SelectedIndexChanged += new System.EventHandler(this.comboSelectData_SelectedIndexChanged);
            this.comboSelectData.MouseEnter += new System.EventHandler(this.comboSelectData_MouseEnter);
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 340);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Data type:";
            // 
            // comboDatatype
            // 
            this.comboDatatype.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.comboDatatype.FormattingEnabled = true;
            this.comboDatatype.Items.AddRange(new object[] {
            "intensity",
            "mV",
            "dB"});
            this.comboDatatype.Location = new System.Drawing.Point(65, 337);
            this.comboDatatype.Name = "comboDatatype";
            this.comboDatatype.Size = new System.Drawing.Size(75, 21);
            this.comboDatatype.TabIndex = 9;
            this.comboDatatype.SelectedIndexChanged += new System.EventHandler(this.comboDatatype_SelectedIndexChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.labelMin);
            this.tabPage2.Controls.Add(this.labelMax);
            this.tabPage2.Controls.Add(this.numMin);
            this.tabPage2.Controls.Add(this.numMax);
            this.tabPage2.Controls.Add(this.chkTimePlotDB);
            this.tabPage2.Controls.Add(this.numRefresh);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.numShowN);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.dataGridView1);
            this.tabPage2.Location = new System.Drawing.Point(4, 5);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(616, 361);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Time plot";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // labelMin
            // 
            this.labelMin.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.labelMin.AutoSize = true;
            this.labelMin.Location = new System.Drawing.Point(338, 340);
            this.labelMin.Name = "labelMin";
            this.labelMin.Size = new System.Drawing.Size(24, 13);
            this.labelMin.TabIndex = 19;
            this.labelMin.Text = "Min";
            this.labelMin.Visible = false;
            // 
            // labelMax
            // 
            this.labelMax.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.labelMax.AutoSize = true;
            this.labelMax.Location = new System.Drawing.Point(259, 341);
            this.labelMax.Name = "labelMax";
            this.labelMax.Size = new System.Drawing.Size(27, 13);
            this.labelMax.TabIndex = 18;
            this.labelMax.Text = "Max";
            this.labelMax.Visible = false;
            // 
            // numMin
            // 
            this.numMin.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.numMin.Location = new System.Drawing.Point(368, 338);
            this.numMin.Maximum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numMin.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.numMin.Name = "numMin";
            this.numMin.Size = new System.Drawing.Size(39, 20);
            this.numMin.TabIndex = 17;
            this.numMin.Value = new decimal(new int[] {
            40,
            0,
            0,
            -2147483648});
            this.numMin.Visible = false;
            this.numMin.ValueChanged += new System.EventHandler(this.numMin_ValueChanged);
            // 
            // numMax
            // 
            this.numMax.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.numMax.Location = new System.Drawing.Point(292, 338);
            this.numMax.Maximum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numMax.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.numMax.Name = "numMax";
            this.numMax.Size = new System.Drawing.Size(39, 20);
            this.numMax.TabIndex = 16;
            this.numMax.Visible = false;
            this.numMax.ValueChanged += new System.EventHandler(this.numMax_ValueChanged);
            // 
            // chkTimePlotDB
            // 
            this.chkTimePlotDB.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.chkTimePlotDB.AutoSize = true;
            this.chkTimePlotDB.Location = new System.Drawing.Point(157, 339);
            this.chkTimePlotDB.Name = "chkTimePlotDB";
            this.chkTimePlotDB.Size = new System.Drawing.Size(85, 17);
            this.chkTimePlotDB.TabIndex = 15;
            this.chkTimePlotDB.Text = "Values in dB";
            this.chkTimePlotDB.UseVisualStyleBackColor = true;
            this.chkTimePlotDB.CheckedChanged += new System.EventHandler(this.ckTimePlotDB_CheckedChanged);
            // 
            // numRefresh
            // 
            this.numRefresh.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.numRefresh.DecimalPlaces = 1;
            this.numRefresh.Location = new System.Drawing.Point(557, 338);
            this.numRefresh.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numRefresh.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numRefresh.Name = "numRefresh";
            this.numRefresh.Size = new System.Drawing.Size(56, 20);
            this.numRefresh.TabIndex = 14;
            this.numRefresh.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numRefresh.ValueChanged += new System.EventHandler(this.numRefresh_ValueChanged);
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(457, 340);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "Refresh rate (sec):";
            // 
            // numShowN
            // 
            this.numShowN.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.numShowN.Increment = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numShowN.Location = new System.Drawing.Point(105, 338);
            this.numShowN.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.numShowN.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numShowN.Name = "numShowN";
            this.numShowN.Size = new System.Drawing.Size(46, 20);
            this.numShowN.TabIndex = 12;
            this.numShowN.Value = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.numShowN.ValueChanged += new System.EventHandler(this.numShowN_ValueChanged);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 340);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Data in graph:";
            // 
            // saveConfigDialog
            // 
            this.saveConfigDialog.FileOk += new System.ComponentModel.CancelEventHandler(this.saveConfigDialog_FileOk);
            // 
            // openConfigDialog
            // 
            this.openConfigDialog.Filter = "txt files (*.txt)|*.txt";
            this.openConfigDialog.RestoreDirectory = true;
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(624, 441);
            this.Controls.Add(this.tabGraph);
            this.Controls.Add(this.toolStrip);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.MinimumSize = new System.Drawing.Size(640, 480);
            this.Name = "FormMain";
            this.Text = "Photonic Imaging App  v1.0";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormMain_FormClosing);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.toolStrip.ResumeLayout(false);
            this.toolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabGraph.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numShift)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numStepdB)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numRefresh)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numShowN)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveConfigurationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadConfigurationToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem exportDataToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem utilitiesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cOMConsoleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;

        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelPort;

        private System.Windows.Forms.ToolStrip toolStrip;
        private System.Windows.Forms.ToolStripButton toolStripButtonSingAcq;
        private System.Windows.Forms.ToolStripButton toolStripButtonContAcq;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ToolStripMenuItem deviceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem selectCOMPortToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem connectToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem disconnectToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem configurationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem graphOptionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripComboBox comboSelCOM;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem singleAcquisitionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem startToolStripMenuItem;
        private System.Windows.Forms.SaveFileDialog saveDataDialog;
        private System.Windows.Forms.ToolStripMenuItem showLinePlotToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showTimePlotToolStripMenuItem;
        private System.Windows.Forms.TabControl tabGraph;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown numShowN;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown numRefresh;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboDatatype;
        private System.Windows.Forms.Label labelSelectData;
        private System.Windows.Forms.ComboBox comboSelectData;
        private System.Windows.Forms.NumericUpDown numStepdB;
        private System.Windows.Forms.Label labelStep;
        private System.Windows.Forms.NumericUpDown numShift;
        private System.Windows.Forms.Label labelShift;
        private System.Windows.Forms.ToolStripButton toolStripButtonExportData;
        private System.Windows.Forms.ToolStripButton toolStripButtonDeleteHistory;
        private ToolStripMenuItem clearHistoryToolStripMenuItem;
        private CheckBox chkTimePlotDB;
        private Label labelMin;
        private Label labelMax;
        private NumericUpDown numMin;
        private NumericUpDown numMax;
        private SaveFileDialog saveConfigDialog;
        private OpenFileDialog openConfigDialog;
        private ToolStripButton toolStripButtonImportData;
        private OpenFileDialog loadDataDialog;
        private ToolStripMenuItem importDataToolStripMenuItem;
    }
}

