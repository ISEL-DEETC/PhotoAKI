﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhotonicImagingApp
{
    public class AData
    {
        private readonly DateTime dateTime;
        private readonly double[] millivolts;
        private readonly double[] db;
        private readonly double[] intensity;
        public static double maxValuedB = -90;
        public static double minValuedB = 0;

        private static readonly double maxMillivolts = 3240; // recalibrado conforme maior valor medido


        public AData(double[] val, DateTime dt)  // val in milivolts
        {
            dateTime = dt;

            if (val.Length == 0)
            {
                millivolts = new double[0];
                db = new double[0];
                intensity = new double[0];
                return;
            }

            millivolts = val;
            db = new double[millivolts.Length];
            intensity = new double[millivolts.Length];

            for (int i = 0; i < millivolts.Length; ++i)
            {
                if (ImageDevice.deviceSettings.pga_gain == 1)
                {
                    intensity[i] = 1 - Math.Max(Math.Min((millivolts[i] - 300) / 2200, 1), 0);
                }
                else
                {
                    intensity[i] = Math.Max(1 - millivolts[i] / maxMillivolts, 0);
                }
                db[i] = 20 * Math.Log10((Math.Max(intensity[i], 3.05e-5)));
                if (db[i] > maxValuedB)
                {
                    maxValuedB = db[i];
                }
                else if (db[i] < minValuedB)
                {
                    minValuedB = db[i];
                }
            }
        }






        public AData(double[] val, DateTime dt, bool isIntensity)  // Solve 
        {
            if (!isIntensity)
            {
                dateTime = dt;

                if (val.Length == 0)
                {
                    millivolts = new double[0];
                    db = new double[0];
                    intensity = new double[0];
                    return;
                }

                millivolts = val;
                db = new double[millivolts.Length];
                intensity = new double[millivolts.Length];

                for (int i = 0; i < millivolts.Length; ++i)
                {
                    if (ImageDevice.deviceSettings.pga_gain == 1)
                    {
                        intensity[i] = 1 - Math.Max(Math.Min((millivolts[i] - 300) / 2200, 1), 0);
                    }
                    else
                    {
                        intensity[i] = Math.Max(1 - millivolts[i] / maxMillivolts, 0);
                    }
                    db[i] = 20 * Math.Log10((Math.Max(intensity[i], 3.05e-5)));
                    if (db[i] > maxValuedB)
                    {
                        maxValuedB = db[i];
                    }
                    else if (db[i] < minValuedB)
                    {
                        minValuedB = db[i];
                    }
                }
            }
            else
            {

                dateTime = dt;

                if (val.Length == 0)
                {
                    millivolts = new double[0];
                    db = new double[0];
                    intensity = new double[0];
                    return;
                }

                intensity = val;
                millivolts = new double[intensity.Length];
                db = new double[intensity.Length];
                //Convert values from intensity 0-1 to milivolt 3300-0
                for (int i = 0; i < intensity.Length; ++i)
                {
                    millivolts[i] = maxMillivolts - intensity[i] * maxMillivolts;
                }

                for (int i = 0; i < millivolts.Length; ++i)
                {
                    db[i] = 20 * Math.Log10((Math.Max(intensity[i], 3.05e-5)));
                    if (db[i] > maxValuedB)
                    {
                        maxValuedB = db[i];
                    }
                    else if (db[i] < minValuedB)
                    {
                        minValuedB = db[i];
                    }
                }
            }
        }




        public AData(double[] val) : this (val, DateTime.Now)
        {
        }

        public DateTime DateTime
        {
            get { return dateTime; }
        }


        public double[] Millivolts
        {
            get { return millivolts; }
        }

        public double[] ValuesdB
        {
            get { return db; }
        }

        public double[] Intensity
        {
            get { return intensity; }
        }

        public int Length
        {
            get { return millivolts.Length; }
        }

        public static void ResetMaxMin() 
        {
   
            maxValuedB = -90;
            minValuedB = 0;
        }
    }
}
