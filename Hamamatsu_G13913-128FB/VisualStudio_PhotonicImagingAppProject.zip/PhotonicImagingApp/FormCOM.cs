﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace PhotonicImagingApp
{
    public partial class FormCOM : Form
    {
        public FormCOM()
        {
            InitializeComponent();
            handlerChangeText = ChangeText;
        }

        private void txtSend_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) {
                if (!string.IsNullOrEmpty(txtSend.Text))
                {
                    if (Program.serialPort1.IsOpen)
                    {
                        Program.serialPort1.Write(txtSend.Text + Environment.NewLine);
                        Program.strConsoleCOM += ">" + txtSend.Text + Environment.NewLine;
                        txtSend.Clear();
                        txtReceive.Text = Program.strConsoleCOM;
                    }
                    else
                    {
                        MessageBox.Show("COM port is not open!");
                    }
                }
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            Program.strConsoleCOM = "";
            txtReceive.Text = Program.strConsoleCOM;
            this.Update();
        }


        public delegate void ChangeTextEvent();
        public ChangeTextEvent handlerChangeText;


        private void ChangeText() {
            txtReceive.Text = Program.strConsoleCOM;
            this.Update();
        }

        private void FormCOM_VisibleChanged(object sender, EventArgs e)
        {
            Program.consoleOpen = this.Visible;
        }

    }
}
