﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhotonicImagingApp
{
    public partial class FormDeviceConfiguration : Form
    {

        const double minAcqInterval = 0.01; // 0,01 s

        public FormDeviceConfiguration()
        {
            InitializeComponent();

            SerialPort serial = Program.serialPort1;
            if (!serial.IsOpen)
            {
                Program.formMain.handlerStatusText("Error: COM port not open.");
                MessageBox.Show("Error: COM port not open.");
                this.Close();
            }
            else
            {
                UpdateControlValues();
            }

        }

        private bool updatingControlValues = false;

        private void UpdateControlValues(){

            updatingControlValues = true;

            numClkFreq.Value = ImageDevice.deviceSettings.clockFrequency;
            numIntTime.Value = ImageDevice.deviceSettings.integrationTime_us;
            rdSensHigh.Checked = ImageDevice.deviceSettings.cfselPin;
            rdSensLow.Checked = !ImageDevice.deviceSettings.cfselPin;
            numPWMperiod.Value = ImageDevice.deviceSettings.pwmPeriodUs;
            numPWMdc.Value = ImageDevice.deviceSettings.pwmDutyCycle;
            chk_pwm_on.Checked = ImageDevice.deviceSettings.pwm_on;
            numChannels.Value = ImageDevice.deviceSettings.nChannels;
            numTimeout.Value = ImageDevice.deviceSettings.acquireTimeout_ms;
            numCaptIntv.Value = Convert.ToDecimal(ImageDevice.deviceSettings.acquireInterval_ms / 1000.0);

            switch (ImageDevice.deviceSettings.pga_gain)
            {
                case 1:
                default:
                    rdGain1.Checked = true;
                    break;
                case 2:
                    rdGain2.Checked = true;
                    break;
                case 4:
                    rdGain4.Checked = true;
                    break;
                case 5:
                    rdGain5.Checked = true;
                    break;
                case 8:
                    rdGain8.Checked = true;
                    break;
                case 10:
                    rdGain10.Checked = true;
                    break;
                case 16:
                    rdGain16.Checked = true;
                    break;
                case 32:
                    rdGain32.Checked = true;
                    break;
            }
            numPGAVref.Value = (decimal)ImageDevice.deviceSettings.pga_vref_mV;
            chkExternalADC.Checked = ImageDevice.deviceSettings.externalADC;
            numSPIfreq.Value = ImageDevice.deviceSettings.spiFreq;
            numAnlgFreq.Value = ImageDevice.deviceSettings.analogOutFreq;
            chkAnlgOutOn.Checked = ImageDevice.deviceSettings.analogOutOn;
            checkDistChannels.Checked = ImageDevice.deviceSettings.equalLimits;
            chkUseOptVref.Checked = ImageDevice.deviceSettings.useOptvref;
            numPGAVref.Enabled = !ImageDevice.deviceSettings.useOptvref;

            updatingControlValues = false;

            UpdateMinimumCaptIntv();

        }

        private void UpdateMinimumCaptIntv() 
        {
            DeviceSettings setgs = ImageDevice.deviceSettings;
            double delayCalcSecs = setgs.integrationTime_us / 1000000.0 + // integration time
                                128 / (double)setgs.clockFrequency + // Video signal transmission time
                                (setgs.nChannels + 1) / 115200.0 + // Serial transmission time
                                0.003 + // Other delay + processing time 
                                (setgs.analogOutOn ? (setgs.nChannels + 4) / setgs.analogOutFreq : 0); // Analog output delay time                  

            double captIntvMin = Math.Max(minAcqInterval, delayCalcSecs);
            numCaptIntv.Minimum = Convert.ToDecimal(captIntvMin);
        }

        private void numPWMperiod_ValueChanged_1(object sender, EventArgs e)
        {
            if (!updatingControlValues) {
                ImageDevice.deviceSettings.pwmPeriodUs = (uint)numPWMperiod.Value;
                ImageDevice.ApplyPWMPeriod();
            }
        }

        private void numPWMdc_ValueChanged(object sender, EventArgs e)
        {
            if (!updatingControlValues)
            {
                ImageDevice.deviceSettings.pwmDutyCycle = (int)numPWMdc.Value;
                ImageDevice.ApplyPWMDutyCycle();
            }
        }

        private void chk_pwm_on_CheckedChanged(object sender, EventArgs e)
        {
            if (!updatingControlValues)
            {
                ImageDevice.deviceSettings.pwm_on = chk_pwm_on.Checked;
                ImageDevice.ApplyPWMState();
            }
        }

        private void numClkFreq_ValueChanged_1(object sender, EventArgs e)
        {
            if (!updatingControlValues)
            {
                ImageDevice.deviceSettings.clockFrequency = (uint)numClkFreq.Value;

                UpdateMinimumCaptIntv();

                ImageDevice.ApplyClockFrequency();
            }
        }

        private void numIntTime_ValueChanged(object sender, EventArgs e)
        {
            if (!updatingControlValues)
            {
                ImageDevice.deviceSettings.integrationTime_us = (uint)numIntTime.Value;

                UpdateMinimumCaptIntv();

                ImageDevice.ApplyIntegrationTime();
            }
        }

        private void rdSensLow_CheckedChanged_1(object sender, EventArgs e)
        {
            if (!updatingControlValues)
            {
                ImageDevice.deviceSettings.cfselPin = rdSensHigh.Checked;
                ImageDevice.ApplyCfSel();
            }
        }

        private void rdSensHigh_CheckedChanged_1(object sender, EventArgs e)
        {
            if (!updatingControlValues)
            {
                ImageDevice.deviceSettings.cfselPin = rdSensHigh.Checked;
                ImageDevice.ApplyCfSel();
            }
        }

        private void chkUseOptVref_CheckedChanged_1(object sender, EventArgs e)
        {
            if (!updatingControlValues)
            {
                if (chkUseOptVref.Checked)
                {
                    int i;
                    switch (ImageDevice.deviceSettings.pga_gain)
                    {
                        case 1:
                        default:
                            i = 0;
                            break;
                        case 2:
                            i = 1;
                            break;
                        case 4:
                            i = 2;
                            break;
                        case 5:
                            i = 3;
                            break;
                        case 8:
                            i = 4;
                            break;
                        case 10:
                            i = 5;
                            break;
                        case 16:
                            i = 6;
                            break;
                        case 32:
                            i = 7;
                            break;
                    }
                    ImageDevice.deviceSettings.pga_vref_mV = DeviceSettings.optimumPGAVref[i];
                    numPGAVref.Value = (decimal)ImageDevice.deviceSettings.pga_vref_mV;
                    ImageDevice.ApplyPGAVref();
                }
                
                ImageDevice.deviceSettings.useOptvref = chkUseOptVref.Checked;
                numPGAVref.Enabled = !chkUseOptVref.Checked;
            }
        }

        private void numPGAVref_ValueChanged_1(object sender, EventArgs e)
        {
            if (!updatingControlValues)
            {
                ImageDevice.deviceSettings.pga_vref_mV = (uint)numPGAVref.Value;
                ImageDevice.ApplyPGAVref();
            }
        }

        private void rdGain1_CheckedChanged_1(object sender, EventArgs e)
        {
            if (!updatingControlValues)
            {
                if (rdGain1.Checked == true)
                {
                    ImageDevice.deviceSettings.pga_gain = 1;
                    ImageDevice.ApplyPGAGain(chkUseOptVref.Checked);
                    numPGAVref.Value = (decimal)ImageDevice.deviceSettings.pga_vref_mV;
                }
            }
        }

        private void rdGain2_CheckedChanged_1(object sender, EventArgs e)
        {
            if (!updatingControlValues)
            {
                if (rdGain2.Checked == true)
                {
                    ImageDevice.deviceSettings.pga_gain = 2;
                    ImageDevice.ApplyPGAGain(chkUseOptVref.Checked);
                    numPGAVref.Value = (decimal)ImageDevice.deviceSettings.pga_vref_mV;
                }
            }
        }

        private void rdGain4_CheckedChanged_1(object sender, EventArgs e)
        {
            if (!updatingControlValues)
            {
                if (rdGain4.Checked == true)
                {
                    ImageDevice.deviceSettings.pga_gain = 4;
                    ImageDevice.ApplyPGAGain(chkUseOptVref.Checked);
                    numPGAVref.Value = (decimal)ImageDevice.deviceSettings.pga_vref_mV;
                }
            }
        }

        private void rdGain5_CheckedChanged_1(object sender, EventArgs e)
        {
            if (!updatingControlValues)
            {
                if (rdGain5.Checked == true)
                {
                    ImageDevice.deviceSettings.pga_gain = 5;
                    ImageDevice.ApplyPGAGain(chkUseOptVref.Checked);
                    numPGAVref.Value = (decimal)ImageDevice.deviceSettings.pga_vref_mV;
                }
            }
        }

        private void rdGain8_CheckedChanged_1(object sender, EventArgs e)
        {
            if (!updatingControlValues)
            {
                if (rdGain8.Checked == true)
                {
                    ImageDevice.deviceSettings.pga_gain = 8;
                    ImageDevice.ApplyPGAGain(chkUseOptVref.Checked);
                    numPGAVref.Value = (decimal)ImageDevice.deviceSettings.pga_vref_mV;
                }
            }
        }

        private void rdGain10_CheckedChanged_1(object sender, EventArgs e)
        {
            if (!updatingControlValues)
            {
                if (rdGain10.Checked == true)
                {
                    ImageDevice.deviceSettings.pga_gain = 10;
                    ImageDevice.ApplyPGAGain(chkUseOptVref.Checked);
                    numPGAVref.Value = (decimal)ImageDevice.deviceSettings.pga_vref_mV;
                }
            }
        }

        private void rdGain16_CheckedChanged_1(object sender, EventArgs e)
        {
            if (!updatingControlValues)
            {
                if (rdGain16.Checked == true)
                {
                    ImageDevice.deviceSettings.pga_gain = 16;
                    ImageDevice.ApplyPGAGain(chkUseOptVref.Checked);
                    numPGAVref.Value = (decimal)ImageDevice.deviceSettings.pga_vref_mV;
                }
            }
        }

        private void rdGain32_CheckedChanged_1(object sender, EventArgs e)
        {
            if (!updatingControlValues)
            {
                if (rdGain32.Checked == true)
                {
                    ImageDevice.deviceSettings.pga_gain = 32;
                    ImageDevice.ApplyPGAGain(chkUseOptVref.Checked);
                    numPGAVref.Value = (decimal)ImageDevice.deviceSettings.pga_vref_mV;
                }
            }
        }
    

        private void numChannels_ValueChanged(object sender, EventArgs e)
        {
            if (!updatingControlValues)
            {
                ImageDevice.deviceSettings.nChannels = (int)numChannels.Value;
                ImageDevice.ApplyChannelsNumber();

                if (checkDistChannels.Checked)
                {

                    int n_ch = ImageDevice.deviceSettings.nChannels;
                    int ch_width = 128 / n_ch;
                    for (int ch = 0; ch < n_ch; ++ch)
                    {
                        ImageDevice.deviceSettings.channelLimits[ch * 2] = ch * ch_width;
                        ImageDevice.deviceSettings.channelLimits[ch * 2 + 1] = (ch + 1) * ch_width - 1;
                    }
                    ImageDevice.ApplyEqualChannelLimits();
                }

                Program.formMain.handlerLinePlotSetup();
                Program.formMain.handlerLinePlotUpdate();
                Program.formMain.handlerTimePlotSetup();
            }

            comboBoxSelCh.Items.Clear();
            for (int i = 1; i <= ImageDevice.deviceSettings.nChannels; ++i)
            {
                comboBoxSelCh.Items.Add(i);
                comboBoxSelCh.SelectedIndex = 0;
            }
        }

        private void checkDistChannels_CheckedChanged(object sender, EventArgs e)
        {
            if (!updatingControlValues)
            {
                if (checkDistChannels.Checked)
                {
                    int n_ch = ImageDevice.deviceSettings.nChannels;
                    int ch_width = 128 / n_ch;
                    for (int ch = 0; ch < n_ch; ++ch)
                    {
                        ImageDevice.deviceSettings.channelLimits[ch * 2] = ch * ch_width;
                        ImageDevice.deviceSettings.channelLimits[ch * 2 + 1] = (ch + 1) * ch_width - 1;
                    }

                    ImageDevice.deviceSettings.equalLimits = checkDistChannels.Checked;
                    ImageDevice.ApplyAllChannelLimits();

                    updatingControlValues = true;

                    if (comboBoxSelCh.SelectedItem != null)
                    {
                        numFstPixel.Value = Math.Max(1, Math.Min(128, (ImageDevice.deviceSettings.channelLimits[(int.Parse(comboBoxSelCh.SelectedItem.ToString()) - 1) * 2] + 1)));
                        numLstPixel.Value = Math.Max(1, Math.Min(128, (ImageDevice.deviceSettings.channelLimits[(int.Parse(comboBoxSelCh.SelectedItem.ToString()) - 1) * 2 + 1] + 1)));
                    }
                    else
                    {
                        numFstPixel.Value = 1;
                        numLstPixel.Value = 1;
                    }

                    updatingControlValues = false;
                }
            }
            
            if (checkDistChannels.Checked)
            {
                numFstPixel.Enabled = false;
                numLstPixel.Enabled = false;
                comboBoxSelCh.Enabled = false;
            }
            else
            {
                numFstPixel.Enabled = true;
                numLstPixel.Enabled = true;
                comboBoxSelCh.Enabled = true;
            }
            
        }
 
        private void comboBoxSelCh_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!updatingControlValues)
            {
                updatingControlValues = true;

                if (comboBoxSelCh.SelectedItem != null)
                {
                    numFstPixel.Value = Math.Max(1, Math.Min(128, (ImageDevice.deviceSettings.channelLimits[(int.Parse(comboBoxSelCh.SelectedItem.ToString()) - 1) * 2] + 1)));
                    numLstPixel.Value = Math.Max(1, Math.Min(128, (ImageDevice.deviceSettings.channelLimits[(int.Parse(comboBoxSelCh.SelectedItem.ToString()) - 1) * 2 + 1] + 1)));
                }
                else
                {
                    numFstPixel.Value = 1;
                    numLstPixel.Value = 1;
                }

                updatingControlValues = false;
            }
        }

        private void numFstPixel_ValueChanged_1(object sender, EventArgs e)
        {
            if (!updatingControlValues)
            {
                if (comboBoxSelCh.SelectedItem != null)
                {
                    ImageDevice.deviceSettings.channelLimits[(int.Parse(comboBoxSelCh.SelectedItem.ToString()) - 1) * 2] = (int)numFstPixel.Value - 1;
                    ImageDevice.ApplyChannelLimits(int.Parse(comboBoxSelCh.SelectedItem.ToString()) - 1);
                }
                ImageDevice.ApplyChannelsNumber();
                if (checkDistChannels.Checked)
                {
                    checkDistChannels.CheckState = CheckState.Unchecked;
                }
            }
        }

        private void numLstPixel_ValueChanged_1(object sender, EventArgs e)
        {
            if (!updatingControlValues)
            {
                if (comboBoxSelCh.SelectedItem != null)
                {
                    ImageDevice.deviceSettings.channelLimits[(int.Parse(comboBoxSelCh.SelectedItem.ToString()) - 1) * 2 + 1] = (int)numLstPixel.Value - 1;
                    ImageDevice.ApplyChannelLimits(int.Parse(comboBoxSelCh.SelectedItem.ToString()) - 1);
                }
                if (checkDistChannels.Checked)
                {
                    checkDistChannels.CheckState = CheckState.Unchecked;
                }
            }
        }


        private void numCaptIntv_ValueChanged(object sender, EventArgs e)
        {
            if (!updatingControlValues)
            {
                ImageDevice.deviceSettings.acquireInterval_ms = (uint)(numCaptIntv.Value * 1000);

                //double intTimeMax = (ImageDevice.deviceSettings.captureInterval_ms * 1000 - 128.0 / (float)ImageDevice.deviceSettings.clockFrequency * 1000000);
                //numIntTime.Maximum = Convert.ToDecimal( Math.Min(65535, Math.Max(intTimeMax, 10) ));

                ImageDevice.ApplyAcquireInterval();

            }
        }

        private void numTimeout_ValueChanged_1(object sender, EventArgs e)
        {
            if (!updatingControlValues)
            {
                ImageDevice.deviceSettings.acquireTimeout_ms = (uint)numTimeout.Value;
                ImageDevice.ApplyAcquireTimeout();
            }
        }

        private void chkExternalADC_CheckedChanged_1(object sender, EventArgs e)
        {
            if (!updatingControlValues)
            {
                ImageDevice.deviceSettings.externalADC = chkExternalADC.Checked;
                ImageDevice.ApplyExternalADCOn();
            }
        }

        private void numSPIfreq_ValueChanged(object sender, EventArgs e)
        {
            if (!updatingControlValues)
            {
                ImageDevice.deviceSettings.spiFreq = (uint)numSPIfreq.Value;
                ImageDevice.ApplySPIFrequency();
            }
        }

        private void chkAnlgOutOn_CheckedChanged_1(object sender, EventArgs e)
        {
            if (!updatingControlValues)
            {
                ImageDevice.deviceSettings.analogOutOn = chkAnlgOutOn.Checked;
                ImageDevice.ApplyAnalogOutOn();
            }
        }

        private void numAnlgFreq_ValueChanged(object sender, EventArgs e)
        {
            if (!updatingControlValues)
            {
                ImageDevice.deviceSettings.analogOutFreq = (uint)numAnlgFreq.Value;
                ImageDevice.ApplyAnalogOutFreq();
            }
        }

        private void btnApply_Click(object sender, EventArgs e)
        {
            ImageDevice.ApplySettings();
            if (ImageDevice.CheckSettings(true) == false)
            {
                MessageBox.Show("Error applying settings.");
                Program.formMain.handlerStatusText("Error applying settings.");
            }
            else
            { 
                Program.formMain.handlerStatusText("Settings OK.");
            }
  
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ImageDevice.ApplyDefaultConfig();
            UpdateControlValues();
        }

    
    }
}
