﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhotonicImagingApp
{
    public static class SCPI
    {

        public static SerialPort serialPort;

        public static void Init(SerialPort sp) 
        {
            serialPort = sp;
        }

        /* Other commands */

        public static void SetEcho(bool echo)
        {
            if (serialPort.IsOpen)
            {
                if (echo)
                {
                    serialPort.WriteLine("*echo on");
                }
                else
                {
                    serialPort.WriteLine("*echo off");
                }
            }
        }

        public static string CommandIDN()
        {
            string idn = "";
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine("*IDN");
                try
                {
                    idn = serialPort.ReadLine();
                }
                catch(Exception e)
                {
                    MessageBox.Show(e.ToString());
                }
            }
            return idn;

        }

        public static void CommandReset()
        {
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine("*RST");
                MessageBox.Show("Trying to reset device...");
            }
        }


        public static bool QueryEcho()
        {
            bool echo = false;
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine("*echo?");
                try
                {
                    string line = serialPort.ReadLine();
                    echo = line.Contains("ON");
                }
                catch(Exception e)
                {
                    MessageBox.Show(e.ToString());
                }
            }
            return echo;

        }

        /* Configure commands */


        public static void SetClockFrequency(uint clk)
        {
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine(":conf:clock " + clk);
            }
        }

        public static uint QueryClockFrequency()
        {
            uint clk = 0;
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine(":conf:clock?");
                try
                {
                    string line = serialPort.ReadLine();
                    clk = uint.Parse(line);
                }
                catch(Exception e)
                { 
                    MessageBox.Show(e.ToString());
                }
            }
            return clk;
        }

        public static void SetIntegrationTime(uint intg)
        {
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine(":conf:intg " + intg);
            }
        }

        public static uint QueryIntegrationTime()
        {
            uint intg = 0;
            if (serialPort.IsOpen)
            {

                serialPort.WriteLine(":conf:intg?");
                try
                {
                    string line = serialPort.ReadLine();
                    intg = uint.Parse(line);
                }
                catch(Exception e)
                {
                    MessageBox.Show(e.ToString()); 
                }
            }
            return intg;

        }

        public static void SetCfSel(bool cfsel)
        {
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine(":conf:csel " + cfsel);
            }
        }

        public static bool QueryCfSel()
        {
            bool cfsel = false;
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine(":conf:csel?");
                try
                {
                    string line = serialPort.ReadLine();
                    cfsel = line.Contains("HIGH");
                }
                catch(Exception e)
                { 
                    MessageBox.Show(e.ToString());
                }
            }
            return cfsel;

        }


        public static void SetChannelsNumber(int n_ch)
        {
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine(":conf:n_ch " + n_ch);
            }
        }

        public static int QueryChannelsNumber()
        {
            int n_ch = 0;
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine(":conf:n_ch?");
                try
                {
                    string line = serialPort.ReadLine();
                    n_ch = int.Parse(line);
                }
                catch(Exception e)
                { 
                    MessageBox.Show(e.ToString());
                }
            }
            return n_ch;


        }

        public static void SetChannelLimits(int n_ch, int min, int max)
        {
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine(":conf:ch_lmt " + n_ch + ',' + min + ',' + max);
            }
        }

        public static void QueryChannelLimits(int n_ch, out int min, out int max)
        {
            min = 0;
            max = 0;
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine(":conf:ch_lmt? " + n_ch);
                try
                {
                    string line = serialPort.ReadLine();
                    min = int.Parse(line);
                    line = serialPort.ReadLine();
                    max = int.Parse(line);
                }
                catch(Exception e)
                { 
                    MessageBox.Show(e.ToString());
                }
            }

        }
        public static void SetEqualChannelLimits()
        {
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine(":conf:ch_equal");
            }
        }

        public static bool QueryEqualChannelLimits()
        {
            bool state = false;
            if (serialPort.IsOpen)
            {

                serialPort.WriteLine(":conf:ch_equal?");
                try
                {
                    string line = serialPort.ReadLine();
                    state = line.Contains("ON");
                }
                catch(Exception e)
                {
                    MessageBox.Show(e.ToString());
                }
            }
            return state;
        }

        public static void SetPWMPeriod(uint period)
        {
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine(":conf:pwm_period " + period);
            }
        }

        public static uint QueryPWMPeriod()
        {
            uint period = 0;
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine(":conf:pwm_period?");
                try
                {
                    string line = serialPort.ReadLine();
                    period = uint.Parse(line);
                }
                catch(Exception e)
                {
                    MessageBox.Show(e.ToString());
                }
            }
            return period;
        }


        public static void SetPWMDutyCycle(int duty)
        {
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine(":conf:pwm_duty " + duty);
            }
        }

        public static int QueryPWMDutyCycle()
        {
            int duty = 0;
            if (serialPort.IsOpen)
            {

                serialPort.WriteLine(":conf:pwm_duty?");
                try
                {
                    string line = serialPort.ReadLine();
                    duty = int.Parse(line);
                }
                catch(Exception e)
                {
                    MessageBox.Show(e.ToString());
                }
            }
            return duty;
        }

        public static void SetPWMState(bool state)
        {
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine(":conf:pwm_state " + state);
            }
        }

        public static bool QueryPWMState()
        {
            bool state = false;
            if (serialPort.IsOpen)
            {

                serialPort.WriteLine(":conf:pwm_state?");
                try
                {
                    string line = serialPort.ReadLine();
                    state = line.Contains("ON");
                }
                catch(Exception e)
                { 
                    MessageBox.Show(e.ToString());
                }
            }
            return state;
        }

        public static void SetPGAGain(uint gain)
        {
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine(":conf:pga_gain " + gain);
            }
        }

        public static uint QueryPGAGain()
        {
            uint gain = 0;
            if (serialPort.IsOpen)
            {

                serialPort.WriteLine(":conf:pga_gain?");
                try
                {
                    string line = serialPort.ReadLine();
                    gain = uint.Parse(line);
                }
                catch(Exception e)
                { 
                    MessageBox.Show(e.ToString()); 
                }
            }
            return gain;
        }

        public static void SetPGAVref(uint vref)
        {
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine(":conf:pga_vref " + vref);
            }
        }

        public static uint QueryPGAVref()
        {
            uint vref = 0;
            if (serialPort.IsOpen)
            {

                serialPort.WriteLine(":conf:pga_vref?");
                try
                {
                    string line = serialPort.ReadLine();
                    vref = uint.Parse(line);
                }
                catch(Exception e)
                {
                    MessageBox.Show(e.ToString());
                }
            }
            return vref;
        }

        public static void SetExternalADC(bool extADCon)
        {
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine(":conf:adc_ext " + extADCon);
            }
        }

        public static bool QueryExternalADC()
        {
            bool adcExt = false;
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine(":conf:adc_ext?");
                try
                {
                    string line = serialPort.ReadLine();
                    adcExt = line.Contains("ON");
                }
                catch(Exception e)
                { 
                    MessageBox.Show(e.ToString());
                }
            }
            return adcExt;
        }

        public static void SetSPIFrequency(uint spiFreq)
        {
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine(":conf:spi_freq " + spiFreq);
            }
        }

        public static uint QuerySPIFrequency()
        {
            uint spiFreq = 0;
            if (serialPort.IsOpen)
            {

                serialPort.WriteLine(":conf:spi_freq?");
                try
                {
                    string line = serialPort.ReadLine();
                    spiFreq = uint.Parse(line);
                }
                catch(Exception e)
                { 
                    MessageBox.Show(e.ToString());
                }
            }
            return spiFreq;

        }

        /* Measure commands */

        public static double[] SingleAcquisition()
        {
            if (!serialPort.IsOpen)
                return null;

            serialPort.WriteLine(":meas:single");

            return GetAcquisitionValues();
        }


        public static void StartContMode()
        {
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine(":meas:cont on");
            }
        }

        public static void StopContMode()
        {
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine(":meas:cont off");
            }
        }



        public static bool QueryContMode()
        {
            bool contCapt = false;
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine(":meas:cont?");
                try
                {
                    string line = serialPort.ReadLine();
                    contCapt = line.Contains("ON");
                }
                catch(Exception e)
                { 
                    MessageBox.Show(e.ToString()); 
                }
            }
            return contCapt;
        }

        public static double[] GetAcquisitionValues()
        {
            if (!serialPort.IsOpen)
            {
                return null;
            }

            double[] resultado = new double[0];

            Int32 i = 0;

            try
            {
                int n = serialPort.ReadByte();

                if (n == 0xff)
                {
                    MessageBox.Show("An unknown error ocurred during signal aquisition.");
                    return null;
                }
                else if (n == 0xfe)
                {
                    MessageBox.Show("Timeout error ocurred during signal acquisition. Timeout value must be adjusted to integration time and clock frequency.");
                    return null;
                }

                resultado = new double[n];
                while (i < n)
                {
                    int high = serialPort.ReadByte();
                    int low = serialPort.ReadByte();
                    Int32 val = Convert.ToInt32((high << 8) + low);
                    resultado[i++] = Convert.ToDouble(Math.Min(val, 32768)) / 32767.0 * 3300;
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                return null;
            };

            return resultado;
        }

        public static void SetAcquireInterval(uint intv)
        {
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine(":meas:interval " + intv);
            }
        }

        public static uint QueryAcquireInterval()
        {
            uint intv = 0;
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine(":meas:interval?");
                try
                {
                    string line = serialPort.ReadLine();
                    intv = uint.Parse(line);
                }
                catch(Exception e)
                { 
                    MessageBox.Show(e.ToString());
                }
            }
            return intv;

        }

        public static void SetAcquireTimeout(uint timeout)
        {
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine(":meas:timeout " + timeout);
            }
        }

        public static uint QueryAcquireTimeout()
        {
            uint timeout = 0;
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine(":meas:timeout?");
                try
                {
                    string line = serialPort.ReadLine();
                    timeout = uint.Parse(line);
                }
                catch(Exception e)
                {
                    MessageBox.Show(e.ToString());
                }
            }
            return timeout;

        }


        public static void SetAnalogOutOn(bool anlg_out)
        {
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine(":conf:anlg_out " + anlg_out);
            }
        }

        public static bool QueryAnalogOutOn()
        {
            bool anlg_out = false;
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine(":conf:anlg_out?");
                try
                {
                    string line = serialPort.ReadLine();
                    anlg_out = line.Contains("ON");
                }
                catch(Exception e)
                {
                    MessageBox.Show(e.ToString());
                }
            }
            return anlg_out;
        }


        public static void SetAnalogOutFreq(uint anlgFreq)
        {
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine(":conf:anlg_freq " + anlgFreq);
            }
        }

        public static uint QueryAnalogOutFreq()
        {
            uint anlgFreq = 0;
            if (serialPort.IsOpen)
            {

                serialPort.WriteLine(":conf:anlg_freq?");
                try
                {
                    string line = serialPort.ReadLine();
                    anlgFreq = uint.Parse(line);
                }
                catch(Exception e)
                { 
                    MessageBox.Show(e.ToString()); 
                }
            }
            return anlgFreq;
        }

        public static void SetOuputModeBytes()
        {
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine(":meas:bytes ");
            }
        }

        public static void SetOuputModeString()
        {
            if (serialPort.IsOpen)
            {
                serialPort.WriteLine(":meas:string ");
            }
        }
    }
}
