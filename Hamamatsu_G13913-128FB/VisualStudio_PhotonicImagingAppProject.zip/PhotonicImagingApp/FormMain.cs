﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Windows.Forms.DataVisualization.Charting;
using System.Drawing.Drawing2D;
using System.IO;

namespace PhotonicImagingApp
{
    public partial class FormMain : Form
    {

        public static FormCOM formCOM;

        public FormMain()
        {
            InitializeComponent();
            //FillTestData();
            DisableButtons();
            comboDatatype.SelectedIndex = 0;
            foreach (TabPage tab in tabGraph.TabPages)
            {
                tab.Text = "";
            }
            handlerStatusText = UpdateStatusBarText;
            handlerProgressBar = UpdateStatusBarProgress;
            handlerLinePlotSetup = LinePlotSetup;
            handlerLinePlotUpdate = LinePlotUpdate;
            handlerTimePlotSetup = TimePlotSetup;

            LinePlotSetup();
            TimePlotSetup();

            timePlotRefreshTimer.Interval = refreshRate; // 2 sec
            timePlotRefreshTimer.Tick += new EventHandler(TimerEventProcessor);

            //EnableButtons(); // DEBUG ONLY

        }

        private static Timer timePlotRefreshTimer = new Timer();
        private void TimerEventProcessor(Object myObject, EventArgs myEventArgs)
        {
            TimePlotAddMissingRows();
        }


        private void Chart1_GetToolTipText(object sender, System.Windows.Forms.DataVisualization.Charting.ToolTipEventArgs e)
        {
            DataPoint dp = null;

            if (e.HitTestResult.ChartElementType == ChartElementType.DataPoint)
            {
                int i = e.HitTestResult.PointIndex;
                dp = e.HitTestResult.Series.Points[i];
            }
            /* Needed if datapoint is on top of chart axes or tickmark */
            else if (e.HitTestResult.ChartElementType == ChartElementType.Axis || e.HitTestResult.ChartElementType == ChartElementType.TickMarks)
            {
                HitTestResult r = chart1.HitTest(e.X, e.Y, ChartElementType.DataPoint);

                if (r.ChartElementType == ChartElementType.DataPoint)
                {
                    dp = r.Series.Points[r.PointIndex];
                }
            }

            if (dp != null)
            {
                if (datatype.CompareTo("intensity") == 0)
                {
                    e.Text = string.Format("Channel {0:D}: {1:F3} relative intensity", Convert.ToInt32(dp.XValue), dp.YValues[0]);
                }
                else if (datatype.CompareTo("mV") == 0)
                {
                    e.Text = string.Format("Channel {0:D}: {1:F1} mV", Convert.ToInt32(dp.XValue), dp.YValues[0]);
                }
                else if (datatype.CompareTo("dB") == 0)
                {
                    e.Text = string.Format("Channel {0:D}: {1:F2} dB", Convert.ToInt32(dp.XValue), dp.YValues[0]);
                }
            }
        }


        private void cOMConsoleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Program.serialPort1.IsOpen)
            {
                if (formCOM == null) {
                    formCOM = new FormCOM();
                }
                formCOM.ShowDialog();
            }
            else {
                MessageBox.Show("Error, please open a COM port first.");
            }
        }

        public delegate void DelegateUpdateStatusText(string text);
        public delegate void DelegateUpdateProgressBar(int progress);

        public DelegateUpdateStatusText handlerStatusText;
        public DelegateUpdateProgressBar handlerProgressBar;

        private void UpdateStatusBarText(string text) {
            toolStripStatusLabel.Text = text;
        }

        private void UpdateStatusBarProgress(int progress)
        {
            toolStripProgressBar1.Value = progress;
        }


        private void DisableButtons()
        {

            toolStripButtonSingAcq.Enabled = false;
            toolStripButtonContAcq.Enabled = false;
  
            singleAcquisitionToolStripMenuItem.Enabled = false;
            startToolStripMenuItem.Enabled = false;
            saveConfigurationToolStripMenuItem.Enabled = false;
            loadConfigurationToolStripMenuItem.Enabled = false;
            cOMConsoleToolStripMenuItem.Enabled = false;
            configurationToolStripMenuItem.Enabled = false;
            disconnectToolStripMenuItem.Enabled = false;
            connectToolStripMenuItem.Enabled = true;
         

        }

        private void EnableButtons()
        {
            toolStripButtonSingAcq.Enabled = true;
            toolStripButtonContAcq.Enabled = true;
            singleAcquisitionToolStripMenuItem.Enabled = true;
            startToolStripMenuItem.Enabled = true;

            saveConfigurationToolStripMenuItem.Enabled = true;
            loadConfigurationToolStripMenuItem.Enabled = true;
            cOMConsoleToolStripMenuItem.Enabled = true;
            configurationToolStripMenuItem.Enabled = true;
            disconnectToolStripMenuItem.Enabled = true;
            connectToolStripMenuItem.Enabled = false;

        }

        private void DisableButtonsContMode() {

            toolStripButtonSingAcq.Enabled = false;
            singleAcquisitionToolStripMenuItem.Enabled = false;
            saveConfigurationToolStripMenuItem.Enabled = false;
            loadConfigurationToolStripMenuItem.Enabled = false;
            clearHistoryToolStripMenuItem.Enabled = false;
            exportDataToolStripMenuItem.Enabled = false;
            importDataToolStripMenuItem.Enabled = false;
            cOMConsoleToolStripMenuItem.Enabled = false;
            configurationToolStripMenuItem.Enabled = false;
            disconnectToolStripMenuItem.Enabled = false;
            toolStripButtonDeleteHistory.Enabled = false;
            toolStripButtonExportData.Enabled = false;
            toolStripButtonImportData.Enabled = false;

        }

        private void EnableButtonsContMode()
        {
            toolStripButtonSingAcq.Enabled = true;
            singleAcquisitionToolStripMenuItem.Enabled = true;
            saveConfigurationToolStripMenuItem.Enabled = true;
            loadConfigurationToolStripMenuItem.Enabled = true;
            clearHistoryToolStripMenuItem.Enabled = true;
            exportDataToolStripMenuItem.Enabled = true;
            importDataToolStripMenuItem.Enabled = true;
            cOMConsoleToolStripMenuItem.Enabled = true;
            configurationToolStripMenuItem.Enabled = true;
            disconnectToolStripMenuItem.Enabled = true;
            toolStripButtonDeleteHistory.Enabled = true;
            toolStripButtonExportData.Enabled = true;
            toolStripButtonImportData.Enabled = true;

        }

        public delegate void UpdateGraphicEvent();

        public UpdateGraphicEvent handlerLinePlotUpdate;
        public UpdateGraphicEvent handlerLinePlotSetup;
        public UpdateGraphicEvent handlerTimePlotSetup;

        private void LinePlotSetup()
        {
            ChartArea newChartArea = new ChartArea();

            chart1.Series.Clear();

            newChartArea.AxisY.MajorGrid.Enabled = true;
            newChartArea.AxisY.MajorTickMark.Enabled = true;
            newChartArea.AxisY.MinorGrid.Enabled = true;
            newChartArea.AxisY.MinorTickMark.Enabled = true;
            newChartArea.AxisX.Minimum = 1;
            newChartArea.AxisX.Maximum = ImageDevice.deviceSettings.nChannels;
            newChartArea.AxisX.Title = "Channels";

            if (datatype.CompareTo("dB") == 0)
            {
                newChartArea.AxisY.Minimum = -5 * stepDB + shift;
                newChartArea.AxisY.Maximum = 0 + shift;
                newChartArea.AxisY.Title = "Logarithmic";
                newChartArea.AxisY.IsReversed = false;
                newChartArea.AxisY.MajorGrid.Interval = stepDB * 2;
                newChartArea.AxisY.MajorTickMark.Interval = stepDB * 2;
                newChartArea.AxisY.MinorGrid.Interval = stepDB;
                newChartArea.AxisY.MinorTickMark.Interval = stepDB;
                numStepdB.Visible = true;
                numShift.Visible = true;
                labelShift.Visible = true;
                labelStep.Visible = true;

            }
            else if (datatype.CompareTo("mV") == 0)
            {
                newChartArea.AxisY.Minimum = 0;
                newChartArea.AxisY.Maximum = 3300;
                newChartArea.AxisY.Title = "mV";
                newChartArea.AxisY.IsReversed = false;
                newChartArea.AxisY.MajorGrid.Interval = 500;
                newChartArea.AxisY.MajorTickMark.Interval = 500;
                newChartArea.AxisY.MinorGrid.Interval = 500;
                newChartArea.AxisY.MinorTickMark.Interval = 100;
                numStepdB.Visible = false;
                numShift.Visible = false;
                labelShift.Visible = false;
                labelStep.Visible = false;
            }
            else if (datatype.CompareTo("intensity") == 0)
            {
                newChartArea.AxisY.Minimum = 0;
                newChartArea.AxisY.Maximum = 1;
                newChartArea.AxisY.Title = "Intensity";
                newChartArea.AxisY.IsReversed = false;
                newChartArea.AxisY.MajorGrid.Interval = 0.1;
                newChartArea.AxisY.MajorTickMark.Interval = 0.1;
                newChartArea.AxisY.MinorGrid.Interval = 0.05;
                newChartArea.AxisY.MinorTickMark.Interval = 0.1;
                numStepdB.Visible = false;
                numShift.Visible = false;
                labelShift.Visible = false;
                labelStep.Visible = false;
            }

            chart1.ChartAreas.Clear();
            chart1.ChartAreas.Add(newChartArea);

            LinePlotUpdate();

        }

        private void LinePlotUpdate()
        {

            Program.updatingChart = true;

            Series series = new Series();
            series.IsXValueIndexed = true;
            series.ChartType = SeriesChartType.Line;
            series.XValueMember = "Channel";
            series.YValueMembers = datatype;
            series.BorderWidth = 2;
            series.MarkerStyle = MarkerStyle.Circle;
            series.MarkerSize = 5;
            series.Color = Color.Cyan;

            AData data = new AData(new double[0]);

            if (selectedData.CompareTo("Last") == 0)
            {
                if (ImageDevice.acquisitionData.Count > 0)
                {
                    data = ImageDevice.acquisitionData.Last();
                }

            }
            else
            {
                Int32 r;
                if (Int32.TryParse(selectedData, out r))
                {
                    data = ImageDevice.acquisitionData[r];
                }
            }

            if (datatype == "mV")
            {
                for (int i = 0; i < data.Length; ++i)
                {
                    DataPoint dp = new DataPoint(i + 1, data.Millivolts[i]);
                    series.Points.Add(dp);
                }
            }
            else if (datatype == "dB")
            {
                for (int i = 0; i < data.Length; ++i)
                {
                    DataPoint dp = new DataPoint(i + 1, data.ValuesdB[i]);
                    series.Points.Add(dp);
                }
            }
            else if (datatype == "intensity")
            {
                for (int i = 0; i < data.Length; ++i)
                {
                    DataPoint dp = new DataPoint(i + 1, data.Intensity[i]);
                    series.Points.Add(dp);
                }
            }

            chart1.Series.Clear();
            chart1.Series.Add(series);
            chart1.Update();

            Program.updatingChart = false;
        }

        static List<Color> colors;
        static List<Color> colors_dB;
        List<Color> interpolateColors(List<Color> stopColors, int count)
        {
            SortedDictionary<float, Color> gradient = new SortedDictionary<float, Color>();
            for (int i = 0; i < stopColors.Count; i++)
                gradient.Add(1f * i / (stopColors.Count - 1), stopColors[i]);
            List<Color> ColorList = new List<Color>();

            using (Bitmap bmp = new Bitmap(count, 1))
            using (Graphics G = Graphics.FromImage(bmp))
            {
                Rectangle bmpCRect = new Rectangle(Point.Empty, bmp.Size);
                LinearGradientBrush br = new LinearGradientBrush
                                        (bmpCRect, Color.Empty, Color.Empty, 0, false);
                ColorBlend cb = new ColorBlend();
                cb.Positions = new float[gradient.Count];
                for (int i = 0; i < gradient.Count; i++)
                    cb.Positions[i] = gradient.ElementAt(i).Key;
                cb.Colors = gradient.Values.ToArray();
                br.InterpolationColors = cb;
                G.FillRectangle(br, bmpCRect);
                for (int i = 0; i < count; i++) ColorList.Add(bmp.GetPixel(i, 0));
                br.Dispose();
            }
            return ColorList;
        }



        private void TimePlotSetup()
        {
            dataGridView1.RowHeadersVisible = true;
            dataGridView1.RowHeadersWidth = 26;
            dataGridView1.ColumnHeadersVisible = false;
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToOrderColumns = false;
            dataGridView1.AllowUserToResizeRows = false;
            dataGridView1.AllowUserToResizeColumns = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None;
            dataGridView1.CellBorderStyle = DataGridViewCellBorderStyle.None;

            List<Color> baseColors = new List<Color>();  // create a color list
            baseColors.Add(Color.Red);
            baseColors.Add(Color.Orange);
            baseColors.Add(Color.Yellow);
            baseColors.Add(Color.Green);
            baseColors.Add(Color.Blue);
            colors = interpolateColors(baseColors, 3301);
            colors_dB = interpolateColors(baseColors, Convert.ToUInt16((numMax.Value - numMin.Value + 1)*10));

            dataGridView1.Columns.Clear();
            dataGridView1.Rows.Clear();

            for (int c = 0; c < ImageDevice.deviceSettings.nChannels; ++c)
            {
                dataGridView1.Columns.Add("", "");
                dataGridView1.Columns[c].MinimumWidth = 2;
            }

            TimePlotAddMissingRows();
            TimePlotResizeRows();

        }


        private void TimePlotAddMissingRows()
        {
         
            int data_i;

            if ( (ImageDevice.acquisitionData.Count - dataGridView1.Rows.Count) > 1000) 
            {
                MessageBox.Show("Warning: high volume of data being processed to be shown on time plot.");
            }

            while (dataGridView1.Rows.Count < ImageDevice.acquisitionData.Count)
            {

                data_i = dataGridView1.Rows.Count;
                dataGridView1.Rows.Add("", "");
                dataGridView1.Rows[data_i].HeaderCell.Value = String.Format("{0}", data_i);
                dataGridView1.Rows[data_i].HeaderCell.ToolTipText = "Data index";

                for (int c = 0; c < ImageDevice.deviceSettings.nChannels; c++)
                {
                    if (c >= ImageDevice.acquisitionData[data_i].Length)
                    {
                        dataGridView1[c, data_i].Style.BackColor = Color.White;
                        dataGridView1[c, data_i].ToolTipText = "Not available.";
                    }
                    else
                    {
                        if (chkTimePlotDB.Checked)
                        {
                            Int16 val = Convert.ToInt16(Math.Abs(ImageDevice.acquisitionData[data_i].ValuesdB[c]) * 10); // All dB values are negative or zero
                            val += Convert.ToInt16(numMax.Value*10);

                            if (val >= 0 && val < colors_dB.Count)
                            {
                                dataGridView1[c, data_i].Style.BackColor = colors_dB[val];
                            }
                            else 
                            {
                                dataGridView1[c, data_i].Style.BackColor = Color.Black;

                                /* // Force limits to max and min values
                                numMax.Value = Convert.ToDecimal(Math.Ceiling(AData.maxValuedB));
                                numMin.Value = Convert.ToDecimal(Math.Floor(AData.minValuedB));
                                TimePlotSetup();*/
                            }

                            dataGridView1[c, data_i].ToolTipText = "Ch " + (c + 1) + ": " + (Math.Round(ImageDevice.acquisitionData[data_i].ValuesdB[c] * 100) / 100.0) + " dB at " + ImageDevice.acquisitionData[data_i].DateTime.ToString();
                        }
                        else
                        {
                            UInt16 val = Convert.ToUInt16(ImageDevice.acquisitionData[data_i].Millivolts[c]);

                            if (val < colors.Count)
                            {
                                dataGridView1[c, data_i].Style.BackColor = colors[val];
                            }
                            else
                            {
                                dataGridView1[c, data_i].Style.BackColor = Color.Black;
                            }
                            dataGridView1[c, data_i].ToolTipText = "Ch " + (c + 1) + ": " + Math.Round(ImageDevice.acquisitionData[data_i].Intensity[c] * 1000) / 1000.0 + " relative intensity at " + ImageDevice.acquisitionData[data_i].DateTime.ToString();
                        }

                    }
                }
            }
            if (dataGridView1.RowCount > 0)
                dataGridView1.FirstDisplayedScrollingRowIndex = dataGridView1.RowCount - 1;

        }

        private void TimePlotResizeRows() 
        {

            /* Variables to adjust row height to window size */
            int maxRow = (int)showN;

            int rowHeight = dataGridView1.ClientSize.Height / maxRow;
            double rowAddEvery = maxRow / (double)(dataGridView1.ClientSize.Height - (maxRow * rowHeight));
            double rowCnt = 0;

            for (int r = 0; r < dataGridView1.Rows.Count; ++r)
            {
                if (rowCnt >= rowAddEvery)
                {
                    dataGridView1.Rows[r].Height = rowHeight + 1;
                    rowCnt -= rowAddEvery;
                }
                else
                {
                    dataGridView1.Rows[r].Height = rowHeight;
                }
                ++rowCnt;
            }

            dataGridView1.RowTemplate.Height = rowHeight;
        }

        private void myDataGridView_SelectionChanged(Object sender, EventArgs e)
        {
            dataGridView1.ClearSelection();
        }

        void dataGridView1_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            object o = dataGridView1.Rows[e.RowIndex].HeaderCell.Value;

            float size, pad;
            if (e.RowBounds.Height < 11)
            {
                size = e.RowBounds.Height;
                pad = 0;
            }
            else
            {
                size = 10;
                pad = 1;
            }
          
            Font f = new Font(dataGridView1.Font.Name, size, FontStyle.Regular );

            e.Graphics.DrawString(
                o != null ? o.ToString() : "",
                f,
                Brushes.Black,
                new PointF((float)e.RowBounds.Left + 2, (float)e.RowBounds.Top + pad));
        }

        private void dataGridView1_Resize(object sender, EventArgs e)
        {
            TimePlotSetup();
            TimePlotResizeRows();
        }


        private void configurationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormDeviceConfiguration formDevCfg = new FormDeviceConfiguration();
            formDevCfg.ShowDialog();
        }

        private void selectCOMPortToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string[] ports = SerialPort.GetPortNames();
            comboSelCOM.Items.Clear();
            comboSelCOM.Items.AddRange(ports);
        }

        private void connectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (comboSelCOM.SelectedItem != null)
            {
                if (!Program.serialPort1.IsOpen)
                {
                    string portName = comboSelCOM.SelectedItem.ToString();
                    Program.serialPort1.PortName = portName;
                    Program.serialPort1.BaudRate = 115200;
                    Program.serialPort1.DataBits = 8;
                    Program.serialPort1.StopBits = StopBits.One;
                    Program.serialPort1.ReadTimeout = 1500;
                    Program.serialPort1.DtrEnable = true;
                    Program.serialPort1.RtsEnable = true;

                    if (connectDevice() == true)
                    {
                        ImageDevice.ApplyDefaultConfig();
                        EnableButtons();

                    }
                    else
                    {
                        toolStripStatusLabel.Text = "IDN fail, trying to reset device...";
                        ImageDevice.Reset();
                        toolStripStatusLabelPort.Text = portName + " port closed.";
                        Program.serialPort1.Close();

                        for (int i = 0; i < 11; ++i)
                        {
                            toolStripProgressBar1.Value = i * 10;
                            System.Threading.Thread.Sleep(100);
                        }
                        if (connectDevice() == true)
                        {
                            ImageDevice.ApplyDefaultConfig();
                            EnableButtons();
                        }
                        else
                        {
                            toolStripStatusLabelPort.Text = portName + " port closed.";
                            Program.serialPort1.Close();
                            toolStripStatusLabel.Text = "Error connecting device.";
                            DisableButtons();
                        }
                    }
  
                }
            }
            else 
            {
                MessageBox.Show("No COM port selected!", "Error",
                 MessageBoxButtons.OK,
                 MessageBoxIcon.Error);
                return;
            }
        }

        private bool connectDevice() 
        {
            string idn;
            try
            {
                Program.serialPort1.Open();
                toolStripStatusLabelPort.Text = Program.serialPort1.PortName + " port open.";
                toolStripStatusLabel.Text = "Requesting IDN...";
                idn = ImageDevice.IDN();
                if (idn.Trim().CompareTo("Image sensor controller") == 0)
                {
                    MessageBox.Show("Device IDN: " + ImageDevice.IDN());
                    toolStripStatusLabel.Text = "Device connected.";
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception e)
            { 
                MessageBox.Show(e.ToString()); 
                return false; 
            };

        }

        private void disconnectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (comboSelCOM.SelectedItem != null)
            {
                Program.serialPort1.Close();
                toolStripStatusLabelPort.Text = "COM port closed.";
                DisableButtons();
            }
        }



        private void SingleAcquisition(object sender, EventArgs e)
        {
            if (ImageDevice.SingleAcquisition())
            {
                TimePlotAddMissingRows();
                LinePlotSetup();
                LinePlotUpdate();
                comboSelectData.SelectedIndex = comboSelectData.FindString("Last");
                toolStripStatusLabel.Text = "Single acquisition done (" + ImageDevice.acquisitionData.Last().DateTime.ToString() + ").";
            }
        }


        private void StartStopAcquire(object sender, EventArgs e)
        {
            if (!ImageDevice.deviceSettings.continuousModeOn)
            {
                toolStripStatusLabel.Text = "Continuous acquisition mode on.";
                DisableButtonsContMode();
                LinePlotSetup();
                ImageDevice.StartContMode();
                timePlotRefreshTimer.Start();
                comboSelectData.SelectedIndex = comboSelectData.FindString("Last");
                toolStripButtonContAcq.Image = Properties.Resources.Stop_16x;
                toolStripButtonContAcq.Invalidate();
                this.Update();
            }
            else
            {
                if (Program.readingData)
                {
                    while (Program.readingData); // 
                }
                ImageDevice.StopContMode();
                timePlotRefreshTimer.Stop();
                Task.Delay(Convert.ToInt32(ImageDevice.deviceSettings.acquireTimeout_ms));
                try
                {
                    Program.serialPort1.DiscardInBuffer();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                };

                EnableButtonsContMode();
                TimePlotAddMissingRows();
                toolStripStatusLabel.Text = "Continuous acquisition mode off.";
                toolStripButtonContAcq.Image = Properties.Resources.StartWithoutDebug_16x;
                toolStripButtonContAcq.Invalidate();
                this.Update();

            }
        }

        private void exportData(object sender, EventArgs e) 
        {
            if (ImageDevice.acquisitionData.Count == 0)
            {
                MessageBox.Show("No data to export!", "Error",
                                 MessageBoxButtons.OK,
                                 MessageBoxIcon.Error);
                return;
            }
            saveDataDialog.ShowDialog();
        }

        private void saveDataDialog_FileOk(object sender, CancelEventArgs e)
        {

            // Criar ficheiro csv
            // exportar

            if (!saveDataDialog.FileName.EndsWith(".csv"))
            {
                saveDataDialog.FileName = saveDataDialog.FileName + ".csv";
            }

            if (!File.Exists(saveDataDialog.FileName)) // If file does not exists
            {
                File.Create(saveDataDialog.FileName).Close(); // Create file
            }
            else // If file already exists
            {
                File.WriteAllText(saveDataDialog.FileName, String.Empty); // Clear file
            }
            using (StreamWriter sw = File.AppendText(saveDataDialog.FileName))
            {
                string line = "Time;\t";
                for (int i = 0; i < ImageDevice.acquisitionData.First().Intensity.Length - 1; ++i)
                {
                    line += "Channel " + (i + 1) + ";\t";
                }
                line += "Channel " + (ImageDevice.acquisitionData.First().Intensity.Length);
                sw.WriteLine(line);

                for (int i = 0; i < ImageDevice.acquisitionData.Count; ++i)
                {
                    line = ImageDevice.acquisitionData[i].DateTime.ToString() + ";\t";
                    for (int j = 0; j < ImageDevice.acquisitionData[i].Length - 1; ++j)
                    {
                        line += Math.Round(ImageDevice.acquisitionData[i].Intensity[j] * 1000) / 1000.0 + ";\t";
                    }
                    if (ImageDevice.acquisitionData[i].Length > 0)
                        line += Math.Round(ImageDevice.acquisitionData[i].Intensity[ImageDevice.acquisitionData[i].Length - 1] * 1000) / 1000.0;
                    else
                    {
                        line += "nan";
                    }
                    sw.WriteLine(line);
                }
            }

            toolStripStatusLabel.Text = "Data exported to '" + saveDataDialog.FileName + "'.";
        }


        private void importData(object sender, EventArgs e)
        {

            if (ImageDevice.acquisitionData.Count != 0)
            {
                DialogResult res = MessageBox.Show("Warning! Importing this set of data you will lose current data. Do you wish to continue? ", "Warning: Will lose data",
                                 MessageBoxButtons.YesNo,
                                 MessageBoxIcon.Warning);
                if (res == DialogResult.No) 
                {
                    return;
                }
            }

            DialogResult r = loadDataDialog.ShowDialog();

            if (r == DialogResult.OK)
            {
                ImageDevice.ClearData();
                //Read the contents of the file into a stream
                var fileStream = loadDataDialog.OpenFile();
                String line = "";

                using (StreamReader reader = new StreamReader(fileStream))
                {
                    // Get number of channels from first line
                    int n_channels;
                    line = reader.ReadLine().Trim();
                    int numberIndex = line.LastIndexOf(' ') + 1;

                    if (!int.TryParse(line.Substring(numberIndex), out n_channels))
                    {
                        MessageBox.Show("Error importing data: unknown number of channels.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        toolStripStatusLabel.Text = "Failed importing data from '" + loadDataDialog.FileName + "'.";
                        return;
                    }

                    // Get dateTime and values from each line
                    while (!String.IsNullOrEmpty(line = reader.ReadLine()))
                    {
                        DateTime dateTime;
                        if (!DateTime.TryParse(line.Substring(0, line.IndexOf(';')).Trim(), out dateTime))
                        {
                            MessageBox.Show("Error importing data: unknown date or time.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            toolStripStatusLabel.Text = "Failed importing data from '" + loadDataDialog.FileName + "'.";
                            return;
                        }

                        double[] values = new double[n_channels];
                        for (int i = 0; i < n_channels; ++i)
                        {
                            line = line.Substring(line.IndexOf('\t')+1);
                            int charIndex = line.IndexOf(';');
                            String numberStr = "";
                            if (charIndex>=0)
                            {
                                numberStr = line.Substring(0, charIndex);
                            }
                            else 
                            {
                                numberStr = line.Substring(0);
                            }
                        
                            if (!double.TryParse(numberStr, out values[i]))
                            {
                                MessageBox.Show("Error importing data: value parsing error.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                toolStripStatusLabel.Text = "Failed importing data from '" + loadDataDialog.FileName + "'.";
                                return;
                            }
                        }

                        AData aData = new AData(values, dateTime, true);
                                          
                            //(values, dateTime);
                        ImageDevice.acquisitionData.Add(aData);

                    }


                    LinePlotSetup();
                    LinePlotUpdate();
                    TimePlotSetup();
                    TimePlotAddMissingRows();
                  
                }
                toolStripStatusLabel.Text = "Data imported from '" + loadDataDialog.FileName + "'.";
            }

        }

        private void clearData(object sender, EventArgs e) 
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure?", "Delete data",
                   MessageBoxButtons.OKCancel,
                   MessageBoxIcon.Question);

            if (dialogResult == DialogResult.OK)
            {
                selectedData = "Last";
                ImageDevice.ClearData();
                dataGridView1.Columns.Clear();
                dataGridView1.Rows.Clear();
                LinePlotUpdate();
                TimePlotSetup();
                toolStripStatusLabel.Text = "Data cleared";
            }
        }

        /* Graphic options variables */
        private String datatype = "intensity";
        private int refreshRate = 2000;
        private Int32 showN = 30;
        private String selectedData = "Last";
        private Int32 stepDB = 6;
        private Int32 shift = 0;

        /* Graphic options controls */
        private void numShowN_ValueChanged(object sender, EventArgs e)
        {
            showN = Convert.ToInt32(numShowN.Value);
            TimePlotResizeRows();
        }

        private void comboDatatype_SelectedIndexChanged(object sender, EventArgs e)
        {
            datatype = comboDatatype.SelectedItem.ToString();
            LinePlotSetup();
            LinePlotUpdate();
        }

        private void comboSelectData_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedData = comboSelectData.SelectedItem.ToString();
            LinePlotUpdate();
        }

        private void comboSelectData_MouseEnter(object sender, EventArgs e)
        {
            comboSelectData.Items.Clear();
            for (int i = 0; i < ImageDevice.acquisitionData.Count; ++i)
            {
                comboSelectData.Items.Add(i.ToString());
            }
            comboSelectData.Items.Add("Last");
        }

        private void numStepdB_ValueChanged(object sender, EventArgs e)
        {
            stepDB = Convert.ToInt32(numStepdB.Value);
            LinePlotSetup();
            LinePlotUpdate();
        }

        private void numShift_ValueChanged(object sender, EventArgs e)
        {
            shift = Convert.ToInt32(numShift.Value);
            LinePlotSetup();
            LinePlotUpdate();
        }

        private void numRefresh_ValueChanged(object sender, EventArgs e)
        {
            refreshRate = Convert.ToInt32(numRefresh.Value * 1000);
            timePlotRefreshTimer.Interval = Convert.ToInt32(refreshRate);
        }

        private void showLinePlotToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabGraph.SelectedIndex = 0;
            showLinePlotToolStripMenuItem.Checked = true;
            showTimePlotToolStripMenuItem.Checked = false;
        }

        private void showTimePlotToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabGraph.SelectedIndex = 1;
            showLinePlotToolStripMenuItem.Checked = false;
            showTimePlotToolStripMenuItem.Checked = true;
        }

        private void ckTimePlotDB_CheckedChanged(object sender, EventArgs e)
        {
            if (chkTimePlotDB.Checked) 
            {
                toolStripStatusLabel.Text = "Time plot values set to dB.";
                labelMax.Visible = true;
                labelMin.Visible = true;
                numMin.Visible = true;
                numMax.Visible = true;
            }
            else 
            {
                toolStripStatusLabel.Text = "Time plot values set to relative intensity.";
                labelMax.Visible = false;
                labelMin.Visible = false;
                numMin.Visible = false;
                numMax.Visible = false;
            }

            TimePlotSetup();
        }

        private void numMax_ValueChanged(object sender, EventArgs e)
        {
            /*
            numMax.Minimum = Convert.ToDecimal(AData.maxValuedB);
            if (numMax.Value < numMax.Minimum){
                return;
            }*/

            numMin.Maximum = numMax.Value;

            TimePlotSetup();
        }

        private void numMin_ValueChanged(object sender, EventArgs e)
        {
            /*
            numMin.Maximum = Convert.ToDecimal(AData.minValuedB);
            if (numMin.Value > numMin.Maximum)
            {
                return;
            }*/

            numMax.Minimum = numMin.Value;
            TimePlotSetup();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("About to exit program?", "Confirm Exit", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
                Close();
        }

        private void FormMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("About to exit program?", "Confirm Exit", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) != DialogResult.OK)
                e.Cancel = true;
        }

        private void saveConfigurationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveConfigDialog.ShowDialog();
        }

        private void loadConfigurationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult r = openConfigDialog.ShowDialog();

            if (r == DialogResult.OK) {
                //Read the contents of the file into a stream
                var fileStream = openConfigDialog.OpenFile();
                String fileContent = "";

                using (StreamReader reader = new StreamReader(fileStream))
                {
                    fileContent = reader.ReadToEnd();
                }
                ImageDevice.deviceSettings.Parse(fileContent);
                ImageDevice.ApplySettings();
                ImageDevice.CheckSettings(true);
                toolStripStatusLabel.Text = "Configurations imported from '" + openConfigDialog.FileName + "'.";
            }
        }

        private void saveConfigDialog_FileOk(object sender, CancelEventArgs e)
        {
            // Criar ficheiro csv
            // exportar

            if (!saveConfigDialog.FileName.EndsWith(".txt"))
            {
                saveConfigDialog.FileName = saveConfigDialog.FileName + ".txt";
            }

            if (!File.Exists(saveConfigDialog.FileName)) // If file does not exist
            {
                File.Create(saveConfigDialog.FileName).Close(); // Create file
            }
            else // If file already exists
            {
                File.WriteAllText(saveConfigDialog.FileName, String.Empty); // Clear file
            }
            using (StreamWriter sw = File.AppendText(saveConfigDialog.FileName))
            {
                sw.Write(ImageDevice.deviceSettings.ToString());
            }

            toolStripStatusLabel.Text = "Configuration options exported to '" + saveConfigDialog.FileName + "'.";
        }


        void FillTestData()
        {

            for (int j = 0; j < 100; ++j)
            {
                double[] val = new double[128];
                double phase = 0;
                phase = Math.PI * Math.Cos(2 * Math.PI * j / 100.0);
                for (int i = 0; i < 128; ++i)
                {
                    val[i] = Math.Abs(Math.Sin(phase + 2 * Math.PI * i / 128.0)) * 2200 + 300;
                }
                ImageDevice.acquisitionData.Add(new AData(val));

            }

        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Este software foi desenvolvido no âmbito do Trabalho Final de Mestrado do curso de " +
                "Engenharia Electrónica e Telecomunicações do Instituto Superior de Engenharia de Lisboa.\n\n" +
                "Autor: Paulo Soares\n" +
                "Setembro de 2021");
        }

    
    }
}
