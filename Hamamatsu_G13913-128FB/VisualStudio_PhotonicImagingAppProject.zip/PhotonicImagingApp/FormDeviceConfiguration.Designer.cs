﻿
namespace PhotonicImagingApp
{
    partial class FormDeviceConfiguration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabLightSource = new System.Windows.Forms.TabPage();
            this.chk_pwm_on = new System.Windows.Forms.CheckBox();
            this.numPWMdc = new System.Windows.Forms.NumericUpDown();
            this.numPWMperiod = new System.Windows.Forms.NumericUpDown();
            this.labelPWMDuty = new System.Windows.Forms.Label();
            this.labelPWMPeriod = new System.Windows.Forms.Label();
            this.tabImgSensor = new System.Windows.Forms.TabPage();
            this.numIntTime = new System.Windows.Forms.NumericUpDown();
            this.numClkFreq = new System.Windows.Forms.NumericUpDown();
            this.groupBoxSigCond = new System.Windows.Forms.GroupBox();
            this.numPGAVref = new System.Windows.Forms.NumericUpDown();
            this.labelDCVal = new System.Windows.Forms.Label();
            this.chkUseOptVref = new System.Windows.Forms.CheckBox();
            this.rdGain32 = new System.Windows.Forms.RadioButton();
            this.rdGain16 = new System.Windows.Forms.RadioButton();
            this.rdGain10 = new System.Windows.Forms.RadioButton();
            this.rdGain8 = new System.Windows.Forms.RadioButton();
            this.rdGain5 = new System.Windows.Forms.RadioButton();
            this.rdGain4 = new System.Windows.Forms.RadioButton();
            this.rdGain2 = new System.Windows.Forms.RadioButton();
            this.rdGain1 = new System.Windows.Forms.RadioButton();
            this.groupBoxSens = new System.Windows.Forms.GroupBox();
            this.rdSensHigh = new System.Windows.Forms.RadioButton();
            this.rdSensLow = new System.Windows.Forms.RadioButton();
            this.labelIntTime = new System.Windows.Forms.Label();
            this.labelCkFreq = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.checkDistChannels = new System.Windows.Forms.CheckBox();
            this.numChannels = new System.Windows.Forms.NumericUpDown();
            this.groupBoxSelCh = new System.Windows.Forms.GroupBox();
            this.numLstPixel = new System.Windows.Forms.NumericUpDown();
            this.numFstPixel = new System.Windows.Forms.NumericUpDown();
            this.labelLstPixel = new System.Windows.Forms.Label();
            this.labelFstPixel = new System.Windows.Forms.Label();
            this.comboBoxSelCh = new System.Windows.Forms.ComboBox();
            this.labelSelCh = new System.Windows.Forms.Label();
            this.labelChNum = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.numAnlgFreq = new System.Windows.Forms.NumericUpDown();
            this.labelAnlgOutFreq = new System.Windows.Forms.Label();
            this.chkAnlgOutOn = new System.Windows.Forms.CheckBox();
            this.numSPIfreq = new System.Windows.Forms.NumericUpDown();
            this.labelSPIfreq = new System.Windows.Forms.Label();
            this.chkExternalADC = new System.Windows.Forms.CheckBox();
            this.numCaptIntv = new System.Windows.Forms.NumericUpDown();
            this.labelCaptFreq = new System.Windows.Forms.Label();
            this.labelTimeout = new System.Windows.Forms.Label();
            this.numTimeout = new System.Windows.Forms.NumericUpDown();
            this.btnApply = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.tabControl.SuspendLayout();
            this.tabLightSource.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numPWMdc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPWMperiod)).BeginInit();
            this.tabImgSensor.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numIntTime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numClkFreq)).BeginInit();
            this.groupBoxSigCond.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numPGAVref)).BeginInit();
            this.groupBoxSens.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numChannels)).BeginInit();
            this.groupBoxSelCh.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numLstPixel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numFstPixel)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numAnlgFreq)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSPIfreq)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCaptIntv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTimeout)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabLightSource);
            this.tabControl.Controls.Add(this.tabImgSensor);
            this.tabControl.Controls.Add(this.tabPage1);
            this.tabControl.Controls.Add(this.tabPage2);
            this.tabControl.Location = new System.Drawing.Point(1, 1);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(303, 253);
            this.tabControl.TabIndex = 0;
            // 
            // tabLightSource
            // 
            this.tabLightSource.Controls.Add(this.chk_pwm_on);
            this.tabLightSource.Controls.Add(this.numPWMdc);
            this.tabLightSource.Controls.Add(this.numPWMperiod);
            this.tabLightSource.Controls.Add(this.labelPWMDuty);
            this.tabLightSource.Controls.Add(this.labelPWMPeriod);
            this.tabLightSource.Location = new System.Drawing.Point(4, 22);
            this.tabLightSource.Name = "tabLightSource";
            this.tabLightSource.Padding = new System.Windows.Forms.Padding(3);
            this.tabLightSource.Size = new System.Drawing.Size(295, 227);
            this.tabLightSource.TabIndex = 0;
            this.tabLightSource.Text = "Light source";
            this.tabLightSource.UseVisualStyleBackColor = true;
            // 
            // chk_pwm_on
            // 
            this.chk_pwm_on.AutoSize = true;
            this.chk_pwm_on.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chk_pwm_on.Location = new System.Drawing.Point(118, 133);
            this.chk_pwm_on.Name = "chk_pwm_on";
            this.chk_pwm_on.Size = new System.Drawing.Size(103, 17);
            this.chk_pwm_on.TabIndex = 27;
            this.chk_pwm_on.Text = "PWM always on";
            this.chk_pwm_on.UseVisualStyleBackColor = true;
            this.chk_pwm_on.CheckedChanged += new System.EventHandler(this.chk_pwm_on_CheckedChanged);
            // 
            // numPWMdc
            // 
            this.numPWMdc.Location = new System.Drawing.Point(161, 107);
            this.numPWMdc.Name = "numPWMdc";
            this.numPWMdc.Size = new System.Drawing.Size(59, 20);
            this.numPWMdc.TabIndex = 26;
            this.numPWMdc.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.numPWMdc.ValueChanged += new System.EventHandler(this.numPWMdc_ValueChanged);
            // 
            // numPWMperiod
            // 
            this.numPWMperiod.Location = new System.Drawing.Point(162, 81);
            this.numPWMperiod.Maximum = new decimal(new int[] {
            200000,
            0,
            0,
            0});
            this.numPWMperiod.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numPWMperiod.Name = "numPWMperiod";
            this.numPWMperiod.Size = new System.Drawing.Size(59, 20);
            this.numPWMperiod.TabIndex = 25;
            this.numPWMperiod.ThousandsSeparator = true;
            this.numPWMperiod.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numPWMperiod.ValueChanged += new System.EventHandler(this.numPWMperiod_ValueChanged_1);
            // 
            // labelPWMDuty
            // 
            this.labelPWMDuty.AutoSize = true;
            this.labelPWMDuty.Location = new System.Drawing.Point(64, 109);
            this.labelPWMDuty.Name = "labelPWMDuty";
            this.labelPWMDuty.Size = new System.Drawing.Size(88, 13);
            this.labelPWMDuty.TabIndex = 24;
            this.labelPWMDuty.Text = "PWM duty-cycle:";
            // 
            // labelPWMPeriod
            // 
            this.labelPWMPeriod.AutoSize = true;
            this.labelPWMPeriod.Location = new System.Drawing.Point(64, 83);
            this.labelPWMPeriod.Name = "labelPWMPeriod";
            this.labelPWMPeriod.Size = new System.Drawing.Size(89, 13);
            this.labelPWMPeriod.TabIndex = 23;
            this.labelPWMPeriod.Text = "PWM period (us):";
            // 
            // tabImgSensor
            // 
            this.tabImgSensor.Controls.Add(this.numIntTime);
            this.tabImgSensor.Controls.Add(this.numClkFreq);
            this.tabImgSensor.Controls.Add(this.groupBoxSigCond);
            this.tabImgSensor.Controls.Add(this.groupBoxSens);
            this.tabImgSensor.Controls.Add(this.labelIntTime);
            this.tabImgSensor.Controls.Add(this.labelCkFreq);
            this.tabImgSensor.Location = new System.Drawing.Point(4, 22);
            this.tabImgSensor.Name = "tabImgSensor";
            this.tabImgSensor.Padding = new System.Windows.Forms.Padding(3);
            this.tabImgSensor.Size = new System.Drawing.Size(295, 227);
            this.tabImgSensor.TabIndex = 1;
            this.tabImgSensor.Text = "Image sensor";
            this.tabImgSensor.UseVisualStyleBackColor = true;
            // 
            // numIntTime
            // 
            this.numIntTime.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numIntTime.Location = new System.Drawing.Point(170, 39);
            this.numIntTime.Maximum = new decimal(new int[] {
            5000000,
            0,
            0,
            0});
            this.numIntTime.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numIntTime.Name = "numIntTime";
            this.numIntTime.Size = new System.Drawing.Size(69, 20);
            this.numIntTime.TabIndex = 20;
            this.numIntTime.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numIntTime.ValueChanged += new System.EventHandler(this.numIntTime_ValueChanged);
            // 
            // numClkFreq
            // 
            this.numClkFreq.Location = new System.Drawing.Point(170, 11);
            this.numClkFreq.Maximum = new decimal(new int[] {
            2000000,
            0,
            0,
            0});
            this.numClkFreq.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.numClkFreq.Name = "numClkFreq";
            this.numClkFreq.Size = new System.Drawing.Size(69, 20);
            this.numClkFreq.TabIndex = 19;
            this.numClkFreq.ThousandsSeparator = true;
            this.numClkFreq.Value = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.numClkFreq.ValueChanged += new System.EventHandler(this.numClkFreq_ValueChanged_1);
            // 
            // groupBoxSigCond
            // 
            this.groupBoxSigCond.Controls.Add(this.numPGAVref);
            this.groupBoxSigCond.Controls.Add(this.labelDCVal);
            this.groupBoxSigCond.Controls.Add(this.chkUseOptVref);
            this.groupBoxSigCond.Controls.Add(this.rdGain32);
            this.groupBoxSigCond.Controls.Add(this.rdGain16);
            this.groupBoxSigCond.Controls.Add(this.rdGain10);
            this.groupBoxSigCond.Controls.Add(this.rdGain8);
            this.groupBoxSigCond.Controls.Add(this.rdGain5);
            this.groupBoxSigCond.Controls.Add(this.rdGain4);
            this.groupBoxSigCond.Controls.Add(this.rdGain2);
            this.groupBoxSigCond.Controls.Add(this.rdGain1);
            this.groupBoxSigCond.Location = new System.Drawing.Point(16, 109);
            this.groupBoxSigCond.Name = "groupBoxSigCond";
            this.groupBoxSigCond.Size = new System.Drawing.Size(263, 110);
            this.groupBoxSigCond.TabIndex = 18;
            this.groupBoxSigCond.TabStop = false;
            this.groupBoxSigCond.Text = "Signal Conditioning";
            // 
            // numPGAVref
            // 
            this.numPGAVref.Enabled = false;
            this.numPGAVref.Location = new System.Drawing.Point(92, 84);
            this.numPGAVref.Maximum = new decimal(new int[] {
            3300,
            0,
            0,
            0});
            this.numPGAVref.Name = "numPGAVref";
            this.numPGAVref.Size = new System.Drawing.Size(62, 20);
            this.numPGAVref.TabIndex = 10;
            this.numPGAVref.ThousandsSeparator = true;
            this.numPGAVref.ValueChanged += new System.EventHandler(this.numPGAVref_ValueChanged_1);
            // 
            // labelDCVal
            // 
            this.labelDCVal.AutoSize = true;
            this.labelDCVal.Location = new System.Drawing.Point(4, 86);
            this.labelDCVal.Name = "labelDCVal";
            this.labelDCVal.Size = new System.Drawing.Size(82, 13);
            this.labelDCVal.TabIndex = 9;
            this.labelDCVal.Text = "Vref value (mV):";
            // 
            // chkUseOptVref
            // 
            this.chkUseOptVref.AutoSize = true;
            this.chkUseOptVref.Checked = true;
            this.chkUseOptVref.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkUseOptVref.Location = new System.Drawing.Point(5, 66);
            this.chkUseOptVref.Name = "chkUseOptVref";
            this.chkUseOptVref.Size = new System.Drawing.Size(109, 17);
            this.chkUseOptVref.TabIndex = 8;
            this.chkUseOptVref.Text = "Use optimum Vref";
            this.chkUseOptVref.UseVisualStyleBackColor = true;
            this.chkUseOptVref.CheckedChanged += new System.EventHandler(this.chkUseOptVref_CheckedChanged_1);
            // 
            // rdGain32
            // 
            this.rdGain32.AutoSize = true;
            this.rdGain32.Location = new System.Drawing.Point(195, 43);
            this.rdGain32.Name = "rdGain32";
            this.rdGain32.Size = new System.Drawing.Size(62, 17);
            this.rdGain32.TabIndex = 7;
            this.rdGain32.TabStop = true;
            this.rdGain32.Text = "Gain 32";
            this.rdGain32.UseVisualStyleBackColor = true;
            this.rdGain32.CheckedChanged += new System.EventHandler(this.rdGain32_CheckedChanged_1);
            // 
            // rdGain16
            // 
            this.rdGain16.AutoSize = true;
            this.rdGain16.Location = new System.Drawing.Point(132, 43);
            this.rdGain16.Name = "rdGain16";
            this.rdGain16.Size = new System.Drawing.Size(62, 17);
            this.rdGain16.TabIndex = 6;
            this.rdGain16.TabStop = true;
            this.rdGain16.Text = "Gain 16";
            this.rdGain16.UseVisualStyleBackColor = true;
            this.rdGain16.CheckedChanged += new System.EventHandler(this.rdGain16_CheckedChanged_1);
            // 
            // rdGain10
            // 
            this.rdGain10.AutoSize = true;
            this.rdGain10.Location = new System.Drawing.Point(70, 43);
            this.rdGain10.Name = "rdGain10";
            this.rdGain10.Size = new System.Drawing.Size(62, 17);
            this.rdGain10.TabIndex = 5;
            this.rdGain10.TabStop = true;
            this.rdGain10.Text = "Gain 10";
            this.rdGain10.UseVisualStyleBackColor = true;
            this.rdGain10.CheckedChanged += new System.EventHandler(this.rdGain10_CheckedChanged_1);
            // 
            // rdGain8
            // 
            this.rdGain8.AutoSize = true;
            this.rdGain8.Location = new System.Drawing.Point(7, 43);
            this.rdGain8.Name = "rdGain8";
            this.rdGain8.Size = new System.Drawing.Size(56, 17);
            this.rdGain8.TabIndex = 4;
            this.rdGain8.TabStop = true;
            this.rdGain8.Text = "Gain 8";
            this.rdGain8.UseVisualStyleBackColor = true;
            this.rdGain8.CheckedChanged += new System.EventHandler(this.rdGain8_CheckedChanged_1);
            // 
            // rdGain5
            // 
            this.rdGain5.AutoSize = true;
            this.rdGain5.Location = new System.Drawing.Point(195, 20);
            this.rdGain5.Name = "rdGain5";
            this.rdGain5.Size = new System.Drawing.Size(56, 17);
            this.rdGain5.TabIndex = 3;
            this.rdGain5.TabStop = true;
            this.rdGain5.Text = "Gain 5";
            this.rdGain5.UseVisualStyleBackColor = true;
            this.rdGain5.CheckedChanged += new System.EventHandler(this.rdGain5_CheckedChanged_1);
            // 
            // rdGain4
            // 
            this.rdGain4.AutoSize = true;
            this.rdGain4.Location = new System.Drawing.Point(132, 20);
            this.rdGain4.Name = "rdGain4";
            this.rdGain4.Size = new System.Drawing.Size(56, 17);
            this.rdGain4.TabIndex = 2;
            this.rdGain4.TabStop = true;
            this.rdGain4.Text = "Gain 4";
            this.rdGain4.UseVisualStyleBackColor = true;
            this.rdGain4.CheckedChanged += new System.EventHandler(this.rdGain4_CheckedChanged_1);
            // 
            // rdGain2
            // 
            this.rdGain2.AutoSize = true;
            this.rdGain2.Location = new System.Drawing.Point(70, 20);
            this.rdGain2.Name = "rdGain2";
            this.rdGain2.Size = new System.Drawing.Size(56, 17);
            this.rdGain2.TabIndex = 1;
            this.rdGain2.TabStop = true;
            this.rdGain2.Text = "Gain 2";
            this.rdGain2.UseVisualStyleBackColor = true;
            this.rdGain2.CheckedChanged += new System.EventHandler(this.rdGain2_CheckedChanged_1);
            // 
            // rdGain1
            // 
            this.rdGain1.AutoSize = true;
            this.rdGain1.Checked = true;
            this.rdGain1.Location = new System.Drawing.Point(7, 20);
            this.rdGain1.Name = "rdGain1";
            this.rdGain1.Size = new System.Drawing.Size(56, 17);
            this.rdGain1.TabIndex = 0;
            this.rdGain1.TabStop = true;
            this.rdGain1.Text = "Gain 1";
            this.rdGain1.UseVisualStyleBackColor = true;
            this.rdGain1.CheckedChanged += new System.EventHandler(this.rdGain1_CheckedChanged_1);
            // 
            // groupBoxSens
            // 
            this.groupBoxSens.Controls.Add(this.rdSensHigh);
            this.groupBoxSens.Controls.Add(this.rdSensLow);
            this.groupBoxSens.Location = new System.Drawing.Point(56, 65);
            this.groupBoxSens.Name = "groupBoxSens";
            this.groupBoxSens.Size = new System.Drawing.Size(183, 38);
            this.groupBoxSens.TabIndex = 17;
            this.groupBoxSens.TabStop = false;
            this.groupBoxSens.Text = "Sensitivity";
            // 
            // rdSensHigh
            // 
            this.rdSensHigh.AutoSize = true;
            this.rdSensHigh.Location = new System.Drawing.Point(110, 15);
            this.rdSensHigh.Name = "rdSensHigh";
            this.rdSensHigh.Size = new System.Drawing.Size(47, 17);
            this.rdSensHigh.TabIndex = 1;
            this.rdSensHigh.Text = "High";
            this.rdSensHigh.UseVisualStyleBackColor = true;
            this.rdSensHigh.CheckedChanged += new System.EventHandler(this.rdSensHigh_CheckedChanged_1);
            // 
            // rdSensLow
            // 
            this.rdSensLow.AutoSize = true;
            this.rdSensLow.Checked = true;
            this.rdSensLow.Location = new System.Drawing.Point(31, 15);
            this.rdSensLow.Name = "rdSensLow";
            this.rdSensLow.Size = new System.Drawing.Size(45, 17);
            this.rdSensLow.TabIndex = 0;
            this.rdSensLow.TabStop = true;
            this.rdSensLow.Text = "Low";
            this.rdSensLow.UseVisualStyleBackColor = true;
            this.rdSensLow.CheckedChanged += new System.EventHandler(this.rdSensLow_CheckedChanged_1);
            // 
            // labelIntTime
            // 
            this.labelIntTime.AutoSize = true;
            this.labelIntTime.Location = new System.Drawing.Point(53, 41);
            this.labelIntTime.Name = "labelIntTime";
            this.labelIntTime.Size = new System.Drawing.Size(102, 13);
            this.labelIntTime.TabIndex = 16;
            this.labelIntTime.Text = "Integration time (us):";
            // 
            // labelCkFreq
            // 
            this.labelCkFreq.AutoSize = true;
            this.labelCkFreq.Location = new System.Drawing.Point(55, 13);
            this.labelCkFreq.Name = "labelCkFreq";
            this.labelCkFreq.Size = new System.Drawing.Size(109, 13);
            this.labelCkFreq.TabIndex = 15;
            this.labelCkFreq.Text = "Clock frequency (Hz):";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.checkDistChannels);
            this.tabPage1.Controls.Add(this.numChannels);
            this.tabPage1.Controls.Add(this.groupBoxSelCh);
            this.tabPage1.Controls.Add(this.labelChNum);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(295, 227);
            this.tabPage1.TabIndex = 2;
            this.tabPage1.Text = "Channels";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // checkDistChannels
            // 
            this.checkDistChannels.AutoSize = true;
            this.checkDistChannels.Location = new System.Drawing.Point(69, 65);
            this.checkDistChannels.Name = "checkDistChannels";
            this.checkDistChannels.Size = new System.Drawing.Size(152, 17);
            this.checkDistChannels.TabIndex = 17;
            this.checkDistChannels.Text = "Distribute channels equally";
            this.checkDistChannels.UseVisualStyleBackColor = true;
            this.checkDistChannels.CheckedChanged += new System.EventHandler(this.checkDistChannels_CheckedChanged);
            // 
            // numChannels
            // 
            this.numChannels.Location = new System.Drawing.Point(176, 40);
            this.numChannels.Maximum = new decimal(new int[] {
            128,
            0,
            0,
            0});
            this.numChannels.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numChannels.Name = "numChannels";
            this.numChannels.Size = new System.Drawing.Size(54, 20);
            this.numChannels.TabIndex = 16;
            this.numChannels.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numChannels.ValueChanged += new System.EventHandler(this.numChannels_ValueChanged);
            // 
            // groupBoxSelCh
            // 
            this.groupBoxSelCh.Controls.Add(this.numLstPixel);
            this.groupBoxSelCh.Controls.Add(this.numFstPixel);
            this.groupBoxSelCh.Controls.Add(this.labelLstPixel);
            this.groupBoxSelCh.Controls.Add(this.labelFstPixel);
            this.groupBoxSelCh.Controls.Add(this.comboBoxSelCh);
            this.groupBoxSelCh.Controls.Add(this.labelSelCh);
            this.groupBoxSelCh.Location = new System.Drawing.Point(68, 88);
            this.groupBoxSelCh.Name = "groupBoxSelCh";
            this.groupBoxSelCh.Size = new System.Drawing.Size(159, 104);
            this.groupBoxSelCh.TabIndex = 15;
            this.groupBoxSelCh.TabStop = false;
            this.groupBoxSelCh.Text = "Limits for selected channel:";
            // 
            // numLstPixel
            // 
            this.numLstPixel.Location = new System.Drawing.Point(99, 75);
            this.numLstPixel.Maximum = new decimal(new int[] {
            128,
            0,
            0,
            0});
            this.numLstPixel.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numLstPixel.Name = "numLstPixel";
            this.numLstPixel.Size = new System.Drawing.Size(53, 20);
            this.numLstPixel.TabIndex = 8;
            this.numLstPixel.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numLstPixel.ValueChanged += new System.EventHandler(this.numLstPixel_ValueChanged_1);
            // 
            // numFstPixel
            // 
            this.numFstPixel.Location = new System.Drawing.Point(99, 49);
            this.numFstPixel.Maximum = new decimal(new int[] {
            128,
            0,
            0,
            0});
            this.numFstPixel.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numFstPixel.Name = "numFstPixel";
            this.numFstPixel.Size = new System.Drawing.Size(53, 20);
            this.numFstPixel.TabIndex = 7;
            this.numFstPixel.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numFstPixel.ValueChanged += new System.EventHandler(this.numFstPixel_ValueChanged_1);
            // 
            // labelLstPixel
            // 
            this.labelLstPixel.AutoSize = true;
            this.labelLstPixel.Location = new System.Drawing.Point(5, 74);
            this.labelLstPixel.Name = "labelLstPixel";
            this.labelLstPixel.Size = new System.Drawing.Size(54, 13);
            this.labelLstPixel.TabIndex = 6;
            this.labelLstPixel.Text = "Last pixel:";
            // 
            // labelFstPixel
            // 
            this.labelFstPixel.AutoSize = true;
            this.labelFstPixel.Location = new System.Drawing.Point(5, 49);
            this.labelFstPixel.Name = "labelFstPixel";
            this.labelFstPixel.Size = new System.Drawing.Size(53, 13);
            this.labelFstPixel.TabIndex = 5;
            this.labelFstPixel.Text = "First pixel:";
            // 
            // comboBoxSelCh
            // 
            this.comboBoxSelCh.FormattingEnabled = true;
            this.comboBoxSelCh.Location = new System.Drawing.Point(99, 19);
            this.comboBoxSelCh.Name = "comboBoxSelCh";
            this.comboBoxSelCh.Size = new System.Drawing.Size(54, 21);
            this.comboBoxSelCh.TabIndex = 3;
            this.comboBoxSelCh.SelectedIndexChanged += new System.EventHandler(this.comboBoxSelCh_SelectedIndexChanged);
            // 
            // labelSelCh
            // 
            this.labelSelCh.AutoSize = true;
            this.labelSelCh.Location = new System.Drawing.Point(5, 22);
            this.labelSelCh.Name = "labelSelCh";
            this.labelSelCh.Size = new System.Drawing.Size(93, 13);
            this.labelSelCh.TabIndex = 4;
            this.labelSelCh.Text = "Selected channel:";
            // 
            // labelChNum
            // 
            this.labelChNum.AutoSize = true;
            this.labelChNum.Location = new System.Drawing.Point(65, 42);
            this.labelChNum.Name = "labelChNum";
            this.labelChNum.Size = new System.Drawing.Size(105, 13);
            this.labelChNum.TabIndex = 14;
            this.labelChNum.Text = "Number of channels:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.numAnlgFreq);
            this.tabPage2.Controls.Add(this.labelAnlgOutFreq);
            this.tabPage2.Controls.Add(this.chkAnlgOutOn);
            this.tabPage2.Controls.Add(this.numSPIfreq);
            this.tabPage2.Controls.Add(this.labelSPIfreq);
            this.tabPage2.Controls.Add(this.chkExternalADC);
            this.tabPage2.Controls.Add(this.numCaptIntv);
            this.tabPage2.Controls.Add(this.labelCaptFreq);
            this.tabPage2.Controls.Add(this.labelTimeout);
            this.tabPage2.Controls.Add(this.numTimeout);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(295, 227);
            this.tabPage2.TabIndex = 3;
            this.tabPage2.Text = "Acquisition";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // numAnlgFreq
            // 
            this.numAnlgFreq.Location = new System.Drawing.Point(168, 140);
            this.numAnlgFreq.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numAnlgFreq.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numAnlgFreq.Name = "numAnlgFreq";
            this.numAnlgFreq.Size = new System.Drawing.Size(62, 20);
            this.numAnlgFreq.TabIndex = 38;
            this.numAnlgFreq.ThousandsSeparator = true;
            this.numAnlgFreq.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numAnlgFreq.ValueChanged += new System.EventHandler(this.numAnlgFreq_ValueChanged);
            // 
            // labelAnlgOutFreq
            // 
            this.labelAnlgOutFreq.AutoSize = true;
            this.labelAnlgOutFreq.Location = new System.Drawing.Point(59, 142);
            this.labelAnlgOutFreq.Name = "labelAnlgOutFreq";
            this.labelAnlgOutFreq.Size = new System.Drawing.Size(89, 13);
            this.labelAnlgOutFreq.TabIndex = 37;
            this.labelAnlgOutFreq.Text = "Analog freq. (Hz):";
            // 
            // chkAnlgOutOn
            // 
            this.chkAnlgOutOn.AutoSize = true;
            this.chkAnlgOutOn.Location = new System.Drawing.Point(62, 118);
            this.chkAnlgOutOn.Name = "chkAnlgOutOn";
            this.chkAnlgOutOn.Size = new System.Drawing.Size(92, 17);
            this.chkAnlgOutOn.TabIndex = 36;
            this.chkAnlgOutOn.Text = "Analog out on";
            this.chkAnlgOutOn.UseVisualStyleBackColor = true;
            this.chkAnlgOutOn.CheckedChanged += new System.EventHandler(this.chkAnlgOutOn_CheckedChanged_1);
            // 
            // numSPIfreq
            // 
            this.numSPIfreq.Location = new System.Drawing.Point(155, 89);
            this.numSPIfreq.Maximum = new decimal(new int[] {
            50000000,
            0,
            0,
            0});
            this.numSPIfreq.Minimum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numSPIfreq.Name = "numSPIfreq";
            this.numSPIfreq.Size = new System.Drawing.Size(75, 20);
            this.numSPIfreq.TabIndex = 35;
            this.numSPIfreq.ThousandsSeparator = true;
            this.numSPIfreq.Value = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numSPIfreq.ValueChanged += new System.EventHandler(this.numSPIfreq_ValueChanged);
            // 
            // labelSPIfreq
            // 
            this.labelSPIfreq.AutoSize = true;
            this.labelSPIfreq.Location = new System.Drawing.Point(61, 91);
            this.labelSPIfreq.Name = "labelSPIfreq";
            this.labelSPIfreq.Size = new System.Drawing.Size(73, 13);
            this.labelSPIfreq.TabIndex = 34;
            this.labelSPIfreq.Text = "SPI freq: (Hz):";
            // 
            // chkExternalADC
            // 
            this.chkExternalADC.AutoSize = true;
            this.chkExternalADC.Location = new System.Drawing.Point(61, 66);
            this.chkExternalADC.Name = "chkExternalADC";
            this.chkExternalADC.Size = new System.Drawing.Size(89, 17);
            this.chkExternalADC.TabIndex = 33;
            this.chkExternalADC.Text = "External ADC";
            this.chkExternalADC.UseVisualStyleBackColor = true;
            this.chkExternalADC.CheckedChanged += new System.EventHandler(this.chkExternalADC_CheckedChanged_1);
            // 
            // numCaptIntv
            // 
            this.numCaptIntv.DecimalPlaces = 3;
            this.numCaptIntv.Location = new System.Drawing.Point(183, 39);
            this.numCaptIntv.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.numCaptIntv.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.numCaptIntv.Name = "numCaptIntv";
            this.numCaptIntv.Size = new System.Drawing.Size(47, 20);
            this.numCaptIntv.TabIndex = 32;
            this.toolTip1.SetToolTip(this.numCaptIntv, "Minimum acquisition time depends on factors such as operation frequency, integrat" +
        "ion time and auxiliary analog output.");
            this.numCaptIntv.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numCaptIntv.ValueChanged += new System.EventHandler(this.numCaptIntv_ValueChanged);
            // 
            // labelCaptFreq
            // 
            this.labelCaptFreq.AutoSize = true;
            this.labelCaptFreq.Location = new System.Drawing.Point(59, 41);
            this.labelCaptFreq.Name = "labelCaptFreq";
            this.labelCaptFreq.Size = new System.Drawing.Size(124, 13);
            this.labelCaptFreq.TabIndex = 31;
            this.labelCaptFreq.Text = "Acquisition interval (sec):";
            // 
            // labelTimeout
            // 
            this.labelTimeout.AutoSize = true;
            this.labelTimeout.Location = new System.Drawing.Point(58, 190);
            this.labelTimeout.Name = "labelTimeout";
            this.labelTimeout.Size = new System.Drawing.Size(67, 13);
            this.labelTimeout.TabIndex = 30;
            this.labelTimeout.Text = "Timeout (ms)";
            this.labelTimeout.Visible = false;
            // 
            // numTimeout
            // 
            this.numTimeout.Location = new System.Drawing.Point(183, 188);
            this.numTimeout.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numTimeout.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numTimeout.Name = "numTimeout";
            this.numTimeout.Size = new System.Drawing.Size(47, 20);
            this.numTimeout.TabIndex = 29;
            this.numTimeout.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numTimeout.Visible = false;
            this.numTimeout.ValueChanged += new System.EventHandler(this.numTimeout_ValueChanged_1);
            // 
            // btnApply
            // 
            this.btnApply.Location = new System.Drawing.Point(108, 256);
            this.btnApply.Name = "btnApply";
            this.btnApply.Size = new System.Drawing.Size(101, 23);
            this.btnApply.TabIndex = 2;
            this.btnApply.Text = "Apply and confirm";
            this.btnApply.UseVisualStyleBackColor = true;
            this.btnApply.Click += new System.EventHandler(this.btnApply_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(235, 256);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(65, 23);
            this.btnClose.TabIndex = 3;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(5, 256);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "Default";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // FormDeviceConfiguration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(304, 281);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnApply);
            this.Controls.Add(this.tabControl);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "FormDeviceConfiguration";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Device configuration";
            this.tabControl.ResumeLayout(false);
            this.tabLightSource.ResumeLayout(false);
            this.tabLightSource.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numPWMdc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPWMperiod)).EndInit();
            this.tabImgSensor.ResumeLayout(false);
            this.tabImgSensor.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numIntTime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numClkFreq)).EndInit();
            this.groupBoxSigCond.ResumeLayout(false);
            this.groupBoxSigCond.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numPGAVref)).EndInit();
            this.groupBoxSens.ResumeLayout(false);
            this.groupBoxSens.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numChannels)).EndInit();
            this.groupBoxSelCh.ResumeLayout(false);
            this.groupBoxSelCh.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numLstPixel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numFstPixel)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numAnlgFreq)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSPIfreq)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCaptIntv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTimeout)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabLightSource;
        private System.Windows.Forms.TabPage tabImgSensor;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.NumericUpDown numIntTime;
        private System.Windows.Forms.NumericUpDown numClkFreq;
        private System.Windows.Forms.GroupBox groupBoxSigCond;
        private System.Windows.Forms.NumericUpDown numPGAVref;
        private System.Windows.Forms.Label labelDCVal;
        private System.Windows.Forms.CheckBox chkUseOptVref;
        private System.Windows.Forms.RadioButton rdGain32;
        private System.Windows.Forms.RadioButton rdGain16;
        private System.Windows.Forms.RadioButton rdGain10;
        private System.Windows.Forms.RadioButton rdGain8;
        private System.Windows.Forms.RadioButton rdGain5;
        private System.Windows.Forms.RadioButton rdGain4;
        private System.Windows.Forms.RadioButton rdGain2;
        private System.Windows.Forms.RadioButton rdGain1;
        private System.Windows.Forms.GroupBox groupBoxSens;
        private System.Windows.Forms.RadioButton rdSensHigh;
        private System.Windows.Forms.RadioButton rdSensLow;
        private System.Windows.Forms.Label labelIntTime;
        private System.Windows.Forms.Label labelCkFreq;
        private System.Windows.Forms.CheckBox checkDistChannels;
        private System.Windows.Forms.NumericUpDown numChannels;
        private System.Windows.Forms.GroupBox groupBoxSelCh;
        private System.Windows.Forms.NumericUpDown numLstPixel;
        private System.Windows.Forms.NumericUpDown numFstPixel;
        private System.Windows.Forms.Label labelLstPixel;
        private System.Windows.Forms.Label labelFstPixel;
        private System.Windows.Forms.ComboBox comboBoxSelCh;
        private System.Windows.Forms.Label labelSelCh;
        private System.Windows.Forms.Label labelChNum;
        private System.Windows.Forms.NumericUpDown numPWMdc;
        private System.Windows.Forms.NumericUpDown numPWMperiod;
        private System.Windows.Forms.Label labelPWMDuty;
        private System.Windows.Forms.Label labelPWMPeriod;
        private System.Windows.Forms.NumericUpDown numAnlgFreq;
        private System.Windows.Forms.Label labelAnlgOutFreq;
        private System.Windows.Forms.CheckBox chkAnlgOutOn;
        private System.Windows.Forms.NumericUpDown numSPIfreq;
        private System.Windows.Forms.Label labelSPIfreq;
        private System.Windows.Forms.CheckBox chkExternalADC;
        private System.Windows.Forms.NumericUpDown numCaptIntv;
        private System.Windows.Forms.Label labelCaptFreq;
        private System.Windows.Forms.Label labelTimeout;
        private System.Windows.Forms.NumericUpDown numTimeout;
        private System.Windows.Forms.Button btnApply;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox chk_pwm_on;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}