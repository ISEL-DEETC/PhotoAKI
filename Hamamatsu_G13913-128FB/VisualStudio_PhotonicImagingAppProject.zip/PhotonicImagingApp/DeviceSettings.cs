﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhotonicImagingApp
{
    public class DeviceSettings
    {
        public bool echo;
        public uint clockFrequency; // Hz
        public uint integrationTime_us; // us
        public bool cfselPin;
        public int nChannels;
        public int[] channelLimits = new int[256];
        public bool equalLimits;
        public uint pwmPeriodUs;
        public int pwmDutyCycle; // 0-100
        public bool pwm_on;
        public bool continuousModeOn;
        public uint acquireInterval_ms;
        public uint acquireTimeout_ms;
        public uint pga_gain;
        public uint pga_vref_mV;
        public bool useOptvref;
        public bool analogOutOn;
        public uint analogOutFreq;
        public bool externalADC;
        public uint spiFreq;
        public bool strNotBytes;

        public const bool defaultEcho = false;
        public const uint defaultClkFreq = 100000;
        public const uint defaultIntTime = 1000;
        public const bool defaultCfSel = false;
        public const int defaultNChannels = 128;
        public const bool defaultEqualLimits = true;
        public const uint defaultPWMPeriod = 1000; // 1ms
        public const int defaultPWMDuty = 50;
        public const bool defaultPWMon = false;
        public const bool defaultContCapt = false;
        public const uint defaultAcqIntv_ms = 1000;
        public const uint defaultAcqTimeout = 700;
        public const uint defaultPgaGain = 1;
        public const uint defaultPGAVref = 1700;
        public const bool defaultUseOptVref = true;
        public const bool defaultAnalogOutOn = true;
        public const uint defaultAnalogOutFreq = 10000;
        public const bool defaultExternalADC = false;
        public const uint defaultSPIfreq = 10000000;
        public const bool defaultStrNotBytes = false;

        public static readonly uint[] optimumPGAVref = { 1700, 1700, 2233, 2300, 2386, 2411, 2447, 2474 };

        public DeviceSettings()
        {
            echo = defaultEcho;
            clockFrequency = defaultClkFreq;
            integrationTime_us = defaultIntTime;
            cfselPin = defaultCfSel;
            continuousModeOn = defaultContCapt;
            acquireInterval_ms = defaultAcqIntv_ms;
            acquireTimeout_ms = defaultAcqTimeout;
            nChannels = defaultNChannels;
            equalLimits = defaultEqualLimits;
            pwmPeriodUs = defaultPWMPeriod;
            pwmDutyCycle = defaultPWMDuty;
            pwm_on = defaultPWMon;
            pga_gain = defaultPgaGain;
            pga_vref_mV = defaultPGAVref;
            analogOutOn = defaultAnalogOutOn;
            analogOutFreq = defaultAnalogOutFreq;
            externalADC = defaultExternalADC;
            spiFreq = defaultSPIfreq;
            useOptvref = defaultUseOptVref;
            SetDefaultChannelLimits();
            strNotBytes = defaultStrNotBytes;
        }

        public void SetDefaultChannelLimits()
        {
            for (int i = 0; i < 128; ++i)
            {
                channelLimits[i * 2] = i;
                channelLimits[i * 2 + 1] = i;
            }
        }

        override public String ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("echo: " + this.echo.ToString());
            sb.AppendLine("clock: " + this.clockFrequency.ToString());
            sb.AppendLine("cfsel: " + this.cfselPin.ToString());
            sb.AppendLine("intg: " + this.integrationTime_us.ToString());
            sb.AppendLine("channels: " + this.nChannels.ToString());
            sb.Append("Channel limits: ");
            for (int i = 0; i < 256; ++i)
            {
                sb.Append(this.channelLimits[i].ToString() + " ");
            }
            sb.Append("\n");
            sb.AppendLine("Equal limits: " + this.equalLimits.ToString());
            sb.AppendLine("PWM period:" + this.pwmPeriodUs.ToString());
            sb.AppendLine("PWM dutycycle:" + this.pwmDutyCycle.ToString());
            sb.AppendLine("PWM state:" + this.pwm_on.ToString());
            sb.AppendLine("Interval: " + this.acquireInterval_ms.ToString());
            sb.AppendLine("Timeout: " + this.acquireTimeout_ms.ToString());
            sb.AppendLine("gain:" + this.pga_gain.ToString());
            sb.AppendLine("vref:" + this.pga_vref_mV.ToString());
            sb.AppendLine("optVref:" + this.useOptvref.ToString());
            sb.AppendLine("vref:" + this.pga_vref_mV.ToString());
            sb.AppendLine("optVref:" + this.useOptvref.ToString());
            sb.AppendLine("Analog output: " + this.analogOutOn.ToString());
            sb.AppendLine("Analog freq: " + this.analogOutFreq.ToString());
            sb.AppendLine("External ADC: " + this.externalADC.ToString());
            sb.AppendLine("SPI freq: " + this.spiFreq.ToString());

            return sb.ToString();
        }

        public void Parse(String str)
        {
            String[] lines = str.Split('\n');

            foreach (var line in lines)
            {
                if (line.StartsWith("echo:"))
                {
                    if (!Boolean.TryParse(line.Substring(line.IndexOf(':') + 1), out this.echo))
                    {
                        this.echo = defaultEcho;
                    }
                }
                else if (line.StartsWith("clock:"))
                {
                    if (!UInt32.TryParse(line.Substring(line.IndexOf(':') + 1), out this.clockFrequency))
                    {
                        this.clockFrequency = defaultClkFreq;
                    }
                }
                else if (line.StartsWith("cfsel:"))
                {
                    if (!Boolean.TryParse(line.Substring(line.IndexOf(':') + 1), out this.cfselPin))
                    {
                        this.cfselPin = defaultCfSel;
                    }
                }
                else if (line.StartsWith("intg:"))
                {
                    if (!UInt32.TryParse(line.Substring(line.IndexOf(':') + 1), out this.integrationTime_us))
                    {
                        this.integrationTime_us = defaultIntTime;
                    }
                }
                else if (line.StartsWith("channels:"))
                {
                    if (!Int32.TryParse(line.Substring(line.IndexOf(':') + 1), out this.nChannels))
                    {
                        this.nChannels = defaultNChannels;
                    }
                }
                else if (line.StartsWith("Channel limits:"))
                {
                    String[] limits = line.Substring(line.IndexOf(':') + 1).Split(' ');
                    uint i = 0;
                    foreach (var limit in limits)
                    {
                        if (i > 255)
                        {
                            break;
                        }
                        if (int.TryParse(limit, out this.channelLimits[i]))
                        {
                            ++i;
                        }

                    }
                }
                else if (line.StartsWith("Equal limits:"))
                {
                    if (!Boolean.TryParse(line.Substring(line.IndexOf(':') + 1), out this.equalLimits))
                    {
                        this.equalLimits = defaultEqualLimits;
                    }
                }
                else if (line.StartsWith("PWM period:"))
                {
                    if (!UInt32.TryParse(line.Substring(line.IndexOf(':') + 1), out this.pwmPeriodUs))
                    {
                        this.pwmPeriodUs = defaultPWMPeriod;
                    }
                }
                else if (line.StartsWith("PWM dutycycle:"))
                {
                    if (!Int32.TryParse(line.Substring(line.IndexOf(':') + 1), out this.pwmDutyCycle))
                    {
                        this.pwmDutyCycle = defaultPWMDuty;
                    }
                }
                else if (line.StartsWith("PWM state:"))
                {
                    if (!Boolean.TryParse(line.Substring(line.IndexOf(':') + 1), out this.pwm_on))
                    {
                        this.pwm_on = defaultPWMon;
                    }
                }
                else if (line.StartsWith("Interval:"))
                {
                    if (!UInt32.TryParse(line.Substring(line.IndexOf(':') + 1), out this.acquireInterval_ms))
                    {
                        this.acquireInterval_ms = defaultAcqIntv_ms;
                    }
                }
                else if (line.StartsWith("Timeout:"))
                {
                    if (!UInt32.TryParse(line.Substring(line.IndexOf(':') + 1), out this.acquireTimeout_ms))
                    {
                        this.acquireTimeout_ms = defaultAcqTimeout;
                    }
                }
                else if (line.StartsWith("gain:"))
                {
                    if (!UInt32.TryParse(line.Substring(line.IndexOf(':') + 1), out this.pga_gain))
                    {
                        this.pga_gain = defaultPgaGain;
                    }
                }
                else if (line.StartsWith("vref:"))
                {
                    if (!UInt32.TryParse(line.Substring(line.IndexOf(':') + 1), out this.pga_vref_mV))
                    {
                        this.pga_vref_mV = defaultPGAVref;
                    }
                }
                else if (line.StartsWith("optVref:"))
                {
                    if (!Boolean.TryParse(line.Substring(line.IndexOf(':') + 1), out this.useOptvref))
                    {
                        this.useOptvref = defaultUseOptVref;
                    }
                }
                else if (line.StartsWith("Analog output:"))
                {
                    if (!Boolean.TryParse(line.Substring(line.IndexOf(':') + 1), out this.analogOutOn))
                    {
                        this.analogOutOn = defaultAnalogOutOn;
                    }
                }
                else if (line.StartsWith("Analog freq:"))
                {
                    if (!UInt32.TryParse(line.Substring(line.IndexOf(':') + 1), out this.analogOutFreq))
                    {
                        this.analogOutFreq = defaultAnalogOutFreq;
                    }
                }
                else if (line.StartsWith("External ADC:"))
                {
                    if (!Boolean.TryParse(line.Substring(line.IndexOf(':') + 1), out this.externalADC))
                    {
                        this.externalADC = defaultExternalADC;
                    }
                }
                else if (line.StartsWith("SPI freq:"))
                {
                    if (!UInt32.TryParse(line.Substring(line.IndexOf(':') + 1), out this.spiFreq))
                    {
                        this.spiFreq = defaultSPIfreq;
                    }
                }
            }

        }

    }
}
