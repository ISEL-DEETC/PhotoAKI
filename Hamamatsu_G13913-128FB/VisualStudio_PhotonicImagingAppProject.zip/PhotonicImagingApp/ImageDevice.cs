﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Ports;
using System.Windows.Forms;
using System.IO;

namespace PhotonicImagingApp
{
    public static class ImageDevice
    {
     
        public static DeviceSettings deviceSettings;
        public static List<AData> acquisitionData;

        public static void Init(SerialPort sp) 
        {
            deviceSettings = new DeviceSettings();
            SCPI.Init(sp);
            acquisitionData = new List<AData>();
            AData.ResetMaxMin();
        }


        public static bool SingleAcquisition()
        {
            if (!SCPI.serialPort.IsOpen)
                return false;

            SCPI.serialPort.DiscardInBuffer();
            double[] values = SCPI.SingleAcquisition();
            if (values == null)
            {
                return false; // erro!
            }

            acquisitionData.Add(new AData(values));

            return true;
        }

        public static void StartContMode() 
        {
            deviceSettings.continuousModeOn = true;
            SCPI.StartContMode();
        }

        public static void StopContMode()
        {
            deviceSettings.continuousModeOn = false;
            SCPI.StopContMode();
        }

        public static bool GetDataContinuousMode()
        {
            if (!SCPI.serialPort.IsOpen)
                return false;

            double[] values = SCPI.GetAcquisitionValues();
            if (values == null)
            {
                return false; // erro!
            }

            acquisitionData.Add(new AData(values));

            return true;
        }

        public static void ClearData()
        {
            acquisitionData.Clear();
            AData.ResetMaxMin();
 
        }

        public static void ApplySettings() {

            double totalOps = 16 + deviceSettings.nChannels;
            double progress = 0;
            double step = 100 / totalOps;

            Program.formMain.handlerStatusText("Applying settings...");
            Program.formMain.handlerProgressBar((int)progress);

            Program.formMain.handlerStatusText("Applying settings... (Clock frequency...)");
            SCPI.SetClockFrequency(deviceSettings.clockFrequency);
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            Program.formMain.handlerStatusText("Applying settings... (Integration time...)");
            SCPI.SetIntegrationTime(deviceSettings.integrationTime_us);
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            Program.formMain.handlerStatusText("Applying settings... (CSel option...)");
            SCPI.SetCfSel(deviceSettings.cfselPin);
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            Program.formMain.handlerStatusText("Applying settings... (Number of channels...)");
            SCPI.SetChannelsNumber(deviceSettings.nChannels);
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

      
            Program.formMain.handlerStatusText("Applying settings... (Channel limits...)");
            if (deviceSettings.equalLimits)
            {
                SCPI.SetEqualChannelLimits();
                progress += step * deviceSettings.nChannels;
                Program.formMain.handlerProgressBar((int)progress);
            }
            else
            {
                for (int i = 0; i < deviceSettings.nChannels; ++i)
                {
                    SCPI.SetChannelLimits(i, deviceSettings.channelLimits[i * 2],
                        deviceSettings.channelLimits[i * 2 + 1]);
                    progress += step;
                    Program.formMain.handlerProgressBar((int)progress);
                }
            }

            Program.formMain.handlerStatusText("Applying settings... (PWM duty-cycle...)");
            SCPI.SetPWMDutyCycle(deviceSettings.pwmDutyCycle);
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            Program.formMain.handlerStatusText("Applying settings... (PWM period...)");
            SCPI.SetPWMPeriod(deviceSettings.pwmPeriodUs);
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            Program.formMain.handlerStatusText("Applying settings... (PWM state...)");
            SCPI.SetPWMState(deviceSettings.pwm_on);
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            Program.formMain.handlerStatusText("Applying settings... (Acquisition interval...)");
            SCPI.SetAcquireInterval(deviceSettings.acquireInterval_ms);
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            Program.formMain.handlerStatusText("Applying settings... (Acquisition timeout...)");
            SCPI.SetAcquireTimeout(deviceSettings.acquireTimeout_ms);
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            Program.formMain.handlerStatusText("Applying settings... (PGA gain...)");
            SCPI.SetPGAGain(deviceSettings.pga_gain);
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            Program.formMain.handlerStatusText("Applying settings... (PGA vref...)");
            SCPI.SetPGAVref(deviceSettings.pga_vref_mV);
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            Program.formMain.handlerStatusText("Applying settings... (External ADC...)");
            SCPI.SetExternalADC(deviceSettings.externalADC);
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            Program.formMain.handlerStatusText("Applying settings... (SPI frequency...)");
            SCPI.SetSPIFrequency(deviceSettings.spiFreq);
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            Program.formMain.handlerStatusText("Applying settings... (Analog out...)");
            SCPI.SetAnalogOutOn(deviceSettings.analogOutOn);
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            Program.formMain.handlerStatusText("Applying settings... (Analog out frequency...)");
            SCPI.SetAnalogOutFreq(deviceSettings.analogOutFreq);
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            Program.formMain.handlerStatusText("Applying settings... (Output mode: bytes...)");
            SCPI.SetOuputModeBytes();
            //progress += step;
            //Program.formMain.handlerProgressBar((int)progress);

            Program.formMain.handlerProgressBar(100);
            Program.formMain.handlerStatusText("Applying settings done.");
        }

        public static bool CheckSettings(bool printMessage)
        {
            double totalOps = 15 + deviceSettings.nChannels;
            double progress = 0;
            double step = 100 / totalOps;

            Program.formMain.handlerStatusText("Verifying applied settings...");
            StringBuilder sb = new StringBuilder();

            bool ret = true;
            SCPI.SetEcho(true);

            SCPI.serialPort.WriteLine("SYNC!");
            string line = SCPI.serialPort.ReadLine();
            while (string.IsNullOrEmpty(line) || !line.Contains("SYNC!"))
            {
                line = SCPI.serialPort.ReadLine();
            }
            SCPI.SetEcho(false);
            SCPI.QueryEcho();

            line = SCPI.serialPort.ReadLine();
            while (string.IsNullOrEmpty(line) || !line.Contains("OFF"))
            {
                line = SCPI.serialPort.ReadLine();
            }

            if (SCPI.QueryClockFrequency().CompareTo(deviceSettings.clockFrequency) != 0)
            {
                ret = false;
                if (printMessage)
                    sb.AppendLine("Wrong clock frequency!");
                Program.formMain.handlerStatusText("Verifying applied settings... (Clock frequency: FAIL)");
            }
            else
            {
                Program.formMain.handlerStatusText("Verifying applied settings... (Clock frequency: OK)");
            }
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            if (SCPI.QueryIntegrationTime().CompareTo(deviceSettings.integrationTime_us) != 0)
            {
                ret = false;
                if (printMessage)
                    sb.AppendLine("Wrong integration time!");
                Program.formMain.handlerStatusText("Verifying applied settings... (Integration time: FAIL)");
            }
            else
            {
                Program.formMain.handlerStatusText("Verifying applied settings... (Integration time: OK)");
            }
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            if (SCPI.QueryCfSel() != deviceSettings.cfselPin)
            {
                ret = false;
                if (printMessage)
                    sb.AppendLine("Wrong CSel option!");
                Program.formMain.handlerStatusText("Verifying applied settings... (CSel option: FAIL)");
            }
            else
            {
                Program.formMain.handlerStatusText("Verifying applied settings... (CSel option: OK)");
            }
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            if (SCPI.QueryChannelsNumber().CompareTo(deviceSettings.nChannels) != 0)
            {
                ret = false;
                if (printMessage)
                    sb.AppendLine("Wrong channels number!");
                Program.formMain.handlerStatusText("Verifying applied settings... (Number of channels: FAIL)");
            }
            else
            {
                Program.formMain.handlerStatusText("Verifying applied settings... (Number of channels: OK)");
            }
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            for (int i = 0; i < deviceSettings.nChannels; ++i)
            {
                int min, max;
                SCPI.QueryChannelLimits(i, out min, out max);
                if ((min.CompareTo(deviceSettings.channelLimits[i * 2]) != 0) ||
                    (max.CompareTo(deviceSettings.channelLimits[i * 2 + 1])) != 0)
                {
                    ret = false;
                    if (printMessage)
                    {
                        sb.AppendLine("Wrong limits in channel " + (i + 1) + "!");
                    }

                    Program.formMain.handlerStatusText("Verifying applied settings... (Channel " + (i + 1) + " limits: FAIL)");
                }
                else
                {
                    Program.formMain.handlerStatusText("Verifying applied settings... (Channel " + (i + 1) + " limits: OK)");
                }
                progress += step;
                Program.formMain.handlerProgressBar((int)progress);
            }

            if (SCPI.QueryPWMPeriod().CompareTo(deviceSettings.pwmPeriodUs) != 0)
            {
                ret = false;
                if (printMessage)
                    sb.AppendLine("Wrong pwm period!");
                Program.formMain.handlerStatusText("Verifying applied settings... (PWM period: FAIL)");
            }
            else
            {
                Program.formMain.handlerStatusText("Verifying applied settings... (PWM period: OK)");
            }
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            if (SCPI.QueryPWMDutyCycle().CompareTo(deviceSettings.pwmDutyCycle) != 0)
            {
                ret = false;
                if (printMessage)
                    sb.AppendLine("Wrong pwm duty-cycle!");
                Program.formMain.handlerStatusText("Verifying applied settings... (PWM duty-cycle: FAIL)");
            }
            else
            {
                Program.formMain.handlerStatusText("Verifying applied settings... (PWM duty-cycle: OK)");
            }
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);


            if (SCPI.QueryPWMState().CompareTo(deviceSettings.pwm_on) != 0)
            {
                ret = false;
                if (printMessage)
                    sb.AppendLine("Wrong pwm state");
                Program.formMain.handlerStatusText("Verifying applied settings... (PWM state FAIL)");
            }
            else
            {
                Program.formMain.handlerStatusText("Verifying applied settings... (PWM state: OK)");
            }
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            if (SCPI.QueryAcquireInterval().CompareTo(deviceSettings.acquireInterval_ms) != 0)
            {
                ret = false;
                if (printMessage)
                    sb.AppendLine("Wrong acquisition interval!");
                Program.formMain.handlerStatusText("Verifying applied settings... (Acquisition interval: FAIL)");
            }
            else
            {
                Program.formMain.handlerStatusText("Verifying applied settings... (Acquisition interval: OK)");
            }
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            if (SCPI.QueryAcquireTimeout().CompareTo(deviceSettings.acquireTimeout_ms) != 0)
            {
                ret = false;
                if (printMessage)
                    sb.AppendLine("Wrong acquisition timeout!");
                Program.formMain.handlerStatusText("Verifying applied settings... (Acquisition timeout: FAIL)");
            }
            else
            {
                Program.formMain.handlerStatusText("Verifying applied settings... (Acquisition timeout: OK)");
            }
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            if (SCPI.QueryPGAGain().CompareTo(deviceSettings.pga_gain) != 0)
            {
                ret = false;
                if (printMessage)
                    sb.AppendLine("Wrong pga gain!");
                Program.formMain.handlerStatusText("Verifying applied settings... (PGA gain: FAIL)");
            }
            else
            {
                Program.formMain.handlerStatusText("Verifying applied settings... (PGA gain:  OK)");
            }
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            if (Math.Abs(SCPI.QueryPGAVref() - (deviceSettings.pga_vref_mV)) > 0.01)
            {
                ret = false;
                if (printMessage)
                    sb.AppendLine("Wrong Vref!");
                Program.formMain.handlerStatusText("Verifying applied settings... (PGA Vref: FAIL)");
            }
            else
            {
                Program.formMain.handlerStatusText("Verifying applied settings... (PGA Vref: OK)");
            }
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            if (SCPI.QueryExternalADC().CompareTo(deviceSettings.externalADC) != 0)
            {
                ret = false;
                if (printMessage)
                    sb.AppendLine("Wrong external ADC!");
                Program.formMain.handlerStatusText("Verifying applied settings... (External ADC: FAIL)");
            }
            else
            {
                Program.formMain.handlerStatusText("Verifying applied settings... (External ADC:OK)");
            }
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            if (SCPI.QuerySPIFrequency().CompareTo(deviceSettings.spiFreq) != 0)
            {
                ret = false;
                if (printMessage)
                    sb.AppendLine("Wrong SPI frequency!");
                Program.formMain.handlerStatusText("Verifying applied settings... (SPI frequency: FAIL)");
            }
            else
            {
                Program.formMain.handlerStatusText("Verifying applied settings... (SPI frequency:  OK)");
            }
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            if (SCPI.QueryAnalogOutOn().CompareTo(deviceSettings.analogOutOn) != 0)
            {
                ret = false;
                if (printMessage)
                    sb.AppendLine("Wrong analog out!");
                Program.formMain.handlerStatusText("Verifying applied settings... (Analog out: FAIL)");
            }
            else
            {
                Program.formMain.handlerStatusText("Verifying applied settings... (Analog out:  OK)");
            }
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            if (SCPI.QueryAnalogOutFreq().CompareTo(deviceSettings.analogOutFreq) != 0)
            {
                ret = false;
                if (printMessage)
                    sb.AppendLine("Wrong analog out frequency!");
                Program.formMain.handlerStatusText("Verifying applied settings... (Analog out frequency:  FAIL)");
            }
            else
            {
                Program.formMain.handlerStatusText("Verifying applied settings... (Analog out frequency:  OK)");
            }
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            Program.formMain.handlerProgressBar(100);

            if (ret)
            {
                Program.formMain.handlerStatusText("Verification complete. Settings are OK.");
            }
            else
            {
                Program.formMain.handlerStatusText("Verification complete. Settings are not OK.");
            }

            if (printMessage && !ret)
            {
                MessageBox.Show(sb.ToString());
            }

            return ret;
        }

        public static void Reset()
        {
            SCPI.CommandReset();
        }

        public static string IDN()
        {
            return SCPI.CommandIDN();
        }

        public static void ApplyDefaultConfig(){
            deviceSettings = new DeviceSettings();
            ApplySettings();
            Program.formMain.handlerStatusText("Default settings applied.");
        }


        public static void ApplyClockFrequency() {
            SCPI.SetClockFrequency(deviceSettings.clockFrequency);
        }
        public static void ApplyIntegrationTime()
        {
            SCPI.SetIntegrationTime(deviceSettings.integrationTime_us);
        }
        public static void ApplyCfSel()
        {
            SCPI.SetCfSel(deviceSettings.cfselPin);
        }
        public static void ApplyChannelsNumber() {
            SCPI.SetChannelsNumber(deviceSettings.nChannels);
        }
        public static void ApplyAllChannelLimits() {
            if (deviceSettings.equalLimits)
            {
                ApplyEqualChannelLimits();
            }
            else
            {
                for (int i = 0; i < deviceSettings.nChannels; ++i)
                {
                    SCPI.SetChannelLimits(i, deviceSettings.channelLimits[i * 2],
                        deviceSettings.channelLimits[i * 2 + 1]);
                }
            }
        }
        public static void ApplyChannelLimits(int channel)
        {
            SCPI.SetChannelLimits(channel, deviceSettings.channelLimits[channel * 2],
            deviceSettings.channelLimits[channel * 2 + 1]);
            deviceSettings.equalLimits = false;
    
        }

        public static void ApplyEqualChannelLimits()
        {
            SCPI.SetEqualChannelLimits();
        }
        public static void ApplyPWMDutyCycle()
        {
            SCPI.SetPWMDutyCycle(deviceSettings.pwmDutyCycle);
        }
        public static void ApplyPWMPeriod()
        {
            SCPI.SetPWMPeriod(deviceSettings.pwmPeriodUs);
        }
        public static void ApplyPWMState()
        {
            SCPI.SetPWMState(deviceSettings.pwm_on);
        }
        public static void ApplyAcquireInterval()
        {
            SCPI.SetAcquireInterval(deviceSettings.acquireInterval_ms);
        }
        public static void ApplyAcquireTimeout()
        {
            SCPI.SetAcquireTimeout(deviceSettings.acquireTimeout_ms);
        }

        public static void ApplyPGAGain(bool optimumDC) 
        {
            SCPI.SetPGAGain(deviceSettings.pga_gain);
            if (optimumDC) {
                uint i;
                switch (deviceSettings.pga_gain)
                {
                    case 1:
                    default:
                        i = 0;
                        break;
                    case 2:
                        i = 1;
                        break;
                    case 4:
                        i = 2;
                        break;
                    case 5:
                        i = 3;
                        break;
                    case 8:
                        i = 4;
                        break;
                    case 10:
                        i = 5;
                        break;
                    case 16:
                        i = 6;
                        break;
                    case 32:
                        i = 7;
                        break;
                }

                deviceSettings.pga_vref_mV = DeviceSettings.optimumPGAVref[i];
                SCPI.SetPGAVref(deviceSettings.pga_vref_mV);
            }
        }

        public static void ApplyPGAVref()
        {
            SCPI.SetPGAVref(deviceSettings.pga_vref_mV);
        }

        public static void ApplyExternalADCOn()
        {
            SCPI.SetExternalADC(deviceSettings.externalADC);
        }

        public static void ApplySPIFrequency()
        {
            SCPI.SetSPIFrequency(deviceSettings.spiFreq);
        }

        public static void ApplyAnalogOutOn() 
        {
            SCPI.SetAnalogOutOn(deviceSettings.analogOutOn);
        }

        public static void ApplyAnalogOutFreq()
        {
            SCPI.SetAnalogOutFreq(deviceSettings.analogOutFreq);
        }




        public static void ReadSettings()
        {
            double totalOps = 16 + deviceSettings.nChannels;
            double progress = 0;
            double step = 100 / totalOps;

            Program.formMain.handlerStatusText("Reading device settings...");

            SCPI.SetEcho(true);

            SCPI.serialPort.WriteLine("SYNC!");
            string line = SCPI.serialPort.ReadLine();
            while (string.IsNullOrEmpty(line) || !line.Contains("SYNC!"))
            {
                line = SCPI.serialPort.ReadLine();
            }
            SCPI.SetEcho(false);
            SCPI.QueryEcho();

            line = SCPI.serialPort.ReadLine();
            while (string.IsNullOrEmpty(line) || !line.Contains("OFF"))
            {
                line = SCPI.serialPort.ReadLine();
            }

            deviceSettings.clockFrequency = SCPI.QueryClockFrequency();
            Program.formMain.handlerStatusText("Reading clock frequency");
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            deviceSettings.integrationTime_us = SCPI.QueryIntegrationTime();
            Program.formMain.handlerStatusText("Reading integration time");
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            deviceSettings.cfselPin = SCPI.QueryCfSel();
            Program.formMain.handlerStatusText("Reading CSel option");
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            deviceSettings.nChannels = SCPI.QueryChannelsNumber();
            Program.formMain.handlerStatusText("Reading channels number");
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            for (int i = 0; i < deviceSettings.nChannels; ++i)
            {
                int min, max;
                SCPI.QueryChannelLimits(i, out min, out max);
                deviceSettings.channelLimits[i * 2] = min;
                deviceSettings.channelLimits[i * 2 + 1] = max;
                Program.formMain.handlerStatusText("Reading channel limits... (Channel " + (i + 1) +")");
                progress += step;
                Program.formMain.handlerProgressBar((int)progress);
            }


            deviceSettings.equalLimits = SCPI.QueryEqualChannelLimits();
            Program.formMain.handlerStatusText("Reading equal channels option");
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            deviceSettings.pwmPeriodUs = SCPI.QueryPWMPeriod();
            Program.formMain.handlerStatusText("Reading PWM period");
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            deviceSettings.pwmDutyCycle = SCPI.QueryPWMDutyCycle();
            Program.formMain.handlerStatusText("Reading PWM duty cycle");
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            deviceSettings.pwm_on = SCPI.QueryPWMState();
            Program.formMain.handlerStatusText("Reading PWM state");
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);



            deviceSettings.acquireInterval_ms = SCPI.QueryAcquireInterval();
            Program.formMain.handlerStatusText("Reading acquisition interval");
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            deviceSettings.acquireTimeout_ms = SCPI.QueryAcquireTimeout();
            Program.formMain.handlerStatusText("Reading acquisition timeout");
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            deviceSettings.pga_gain = SCPI.QueryPGAGain();
            Program.formMain.handlerStatusText("Reading PGA gain");
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            deviceSettings.pga_vref_mV = SCPI.QueryPGAVref();
            Program.formMain.handlerStatusText("Reading PGA vref");
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            deviceSettings.externalADC = SCPI.QueryExternalADC();
            Program.formMain.handlerStatusText("Reading external ADC on/off");
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            deviceSettings.spiFreq = SCPI.QuerySPIFrequency();
            Program.formMain.handlerStatusText("Reading SPI frequency");
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            deviceSettings.analogOutOn = SCPI.QueryAnalogOutOn();
            Program.formMain.handlerStatusText("Reading analog output on/off");
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            deviceSettings.analogOutFreq = SCPI.QueryAnalogOutFreq();
            Program.formMain.handlerStatusText("Reading analog output frequency");
            progress += step;
            Program.formMain.handlerProgressBar((int)progress);

            Program.formMain.handlerProgressBar(100);
            Program.formMain.handlerStatusText("Device settings read.");
        }

  

    }
    


    
}
