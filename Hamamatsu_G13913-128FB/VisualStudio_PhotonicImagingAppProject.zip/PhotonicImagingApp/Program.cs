﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace PhotonicImagingApp
{
    static class Program
    {
        public static System.IO.Ports.SerialPort serialPort1;
        public static FormMain formMain;
        public static string strConsoleCOM = "";
        public static bool consoleOpen = false;
        public static bool updatingChart = false;
        public static bool readingData = false;


        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            serialPort1 = new System.IO.Ports.SerialPort();
            ImageDevice.Init(serialPort1);
            formMain = new FormMain();
            serialPort1.DataReceived += serialPort1_DataReceived;
           
            try
            {
                Application.Run(formMain);
            }
            catch(Exception e)
            {
                dumpData();
                MessageBox.Show(e.ToString());
            };

        }

        static private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {

            if (consoleOpen)
            {
                string str = serialPort1.ReadExisting();
                strConsoleCOM += str;
                FormMain.formCOM.Invoke(FormMain.formCOM.handlerChangeText);
            }
            else if (ImageDevice.deviceSettings.continuousModeOn && !updatingChart)
            {
                readingData = true;
                bool ret = ImageDevice.GetDataContinuousMode();
                readingData = false;
                if (ret)
                    formMain.Invoke(formMain.handlerLinePlotUpdate);

            }

        }

        static private void dumpData()
        {

            string filename = Application.UserAppDataPath + "data_dump_" + DateTime.Now.ToString("yyyyMMdd_hhmmss") + ".csv";
    

            if (!File.Exists(filename)) // If file does not exist
            {
                File.Create(filename).Close() ; // Create file
            }
            else // If file already exists
            {
                File.WriteAllText(filename, String.Empty); // Clear file
            }

            using (StreamWriter sw = File.AppendText(filename))
            {
                string line = "Time;\t";
                for (int i = 0; i < ImageDevice.acquisitionData.First().Intensity.Length - 1; ++i)
                {
                    line += "Channel " + (i + 1) + ";\t";
                }
                line += "Channel " + (ImageDevice.acquisitionData.First().Intensity.Length);
                sw.WriteLine(line);

                for (int i = 0; i < ImageDevice.acquisitionData.Count; ++i)
                {
                    line = ImageDevice.acquisitionData[i].DateTime.ToString() + ";\t";
                    for (int j = 0; j < ImageDevice.acquisitionData[i].Length - 1; ++j)
                    {
                        line += Math.Round(ImageDevice.acquisitionData[i].Intensity[j] * 1000) / 1000.0 + ";\t";
                    }
                    if (ImageDevice.acquisitionData[i].Length > 0)
                        line += Math.Round(ImageDevice.acquisitionData[i].Intensity[ImageDevice.acquisitionData[i].Length - 1] * 1000) / 1000.0;
                    else
                    {
                        line += "nan";
                    }
                    sw.WriteLine(line);
                }
            }
            MessageBox.Show("Program data was saved to '" + filename + "'.", "Critical error", MessageBoxButtons.OK, MessageBoxIcon.Information);


        }
    }
}
